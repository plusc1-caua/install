<?php
include("SubMenu.php")
?>
<?php

if(isset($_GET['ler'])){

    switch($_GET['ler']){
        case 'all':$ler='tudo';$tipo='tudo';break;
        case 'others':$ler='others';$tipo='outros';break;
        case 'fatu':$ler='fatu';$tipo='fatura';break;
        case 'accs':$ler='contas';$tipo='conta';break;
        case 'reve':$ler='revenda';$tipo='revenda';break;
        case 'subreve':$ler='subrevenda';$tipo='subrevenda';break;
        case 'usuario':$ler='usuario';$tipo='usuario';break;
        case 'chamados':$ler='chamados';$tipo='chamados';break;
        default:$ler='nada';break;
    }
    if($ler=='nada'){

    }elseif($ler=='tudo'){

// Notificações
        $SQLnoti= "select * from  notificacoes where lido='nao' and usuario_id='".$_SESSION['usuarioID']."'";
        $SQLnoti = $conn->prepare($SQLnoti);
        $SQLnoti->execute();
        $totalnoti = $SQLnoti->rowCount();

        if($totalnoti>0){
            while($tudo= $SQLnoti->fetch()){

                $SQLnotiler= "update notificacoes set lido='sim' where id='".$tudo['id']."'";
                $SQLnotiler = $conn->prepare($SQLnotiler);
                $SQLnotiler->execute();

            }
        }

    }elseif($ler=='others'){

        // Notificações
        $SQLnoti= "select * from  notificacoes where lido='nao' and tipo='outros' and usuario_id='".$_SESSION['usuarioID']."'";
        $SQLnoti = $conn->prepare($SQLnoti);
        $SQLnoti->execute();
        $totalnoti = $SQLnoti->rowCount();

        if($totalnoti>0){
            while($tudo= $SQLnoti->fetch()){

                $SQLnotiler= "update notificacoes set lido='sim' where id='".$tudo['id']."'";
                $SQLnotiler = $conn->prepare($SQLnotiler);
                $SQLnotiler->execute();

            }
        }

    }elseif($ler=='fatu'){

        // Notificações
        $SQLnoti= "select * from  notificacoes where lido='nao' and tipo='fatura' and usuario_id='".$_SESSION['usuarioID']."'";
        $SQLnoti = $conn->prepare($SQLnoti);
        $SQLnoti->execute();
        $totalnoti = $SQLnoti->rowCount();

        if($totalnoti>0){
            while($tudo= $SQLnoti->fetch()){

                $SQLnotiler= "update notificacoes set lido='sim' where id='".$tudo['id']."'";
                $SQLnotiler = $conn->prepare($SQLnotiler);
                $SQLnotiler->execute();

            }
        }

    }elseif($ler=='contas'){

        // Notificações
        $SQLnoti= "select * from  notificacoes where lido='nao' and tipo='conta' and usuario_id='".$_SESSION['usuarioID']."'";
        $SQLnoti = $conn->prepare($SQLnoti);
        $SQLnoti->execute();
        $totalnoti = $SQLnoti->rowCount();

        if($totalnoti>0){
            while($tudo= $SQLnoti->fetch()){

                $SQLnotiler= "update notificacoes set lido='sim' where id='".$tudo['id']."'";
                $SQLnotiler = $conn->prepare($SQLnotiler);
                $SQLnotiler->execute();

            }
        }

    }elseif($ler=='revenda'){

        // Notificações
        $SQLnoti= "select * from  notificacoes where lido='nao' and tipo='revenda' and usuario_id='".$_SESSION['usuarioID']."'";
        $SQLnoti = $conn->prepare($SQLnoti);
        $SQLnoti->execute();
        $totalnoti = $SQLnoti->rowCount();

        if($totalnoti>0){
            while($tudo= $SQLnoti->fetch()){

                $SQLnotiler= "update notificacoes set lido='sim' where id='".$tudo['id']."'";
                $SQLnotiler = $conn->prepare($SQLnotiler);
                $SQLnotiler->execute();

            }
        }

    }elseif($ler=='subrevenda'){

        // Notificações
        $SQLnoti= "select * from  notificacoes where lido='nao' and tipo='subrevenda' and usuario_id='".$_SESSION['usuarioID']."'";
        $SQLnoti = $conn->prepare($SQLnoti);
        $SQLnoti->execute();
        $totalnoti = $SQLnoti->rowCount();

        if($totalnoti>0){
            while($tudo= $SQLnoti->fetch()){

                $SQLnotiler= "update notificacoes set lido='sim' where id='".$tudo['id']."'";
                $SQLnotiler = $conn->prepare($SQLnotiler);
                $SQLnotiler->execute();

            }
        }

    }elseif($ler=='usuario'){

        // Notificações
        $SQLnoti= "select * from  notificacoes where lido='nao' and tipo='subrevenda' and usuario_id='".$_SESSION['usuarioID']."'";
        $SQLnoti = $conn->prepare($SQLnoti);
        $SQLnoti->execute();
        $totalnoti = $SQLnoti->rowCount();

        if($totalnoti>0){
            while($tudo= $SQLnoti->fetch()){

                $SQLnotiler= "update notificacoes set lido='sim' where id='".$tudo['id']."'";
                $SQLnotiler = $conn->prepare($SQLnotiler);
                $SQLnotiler->execute();

            }
        }

    }elseif($ler=='chamados'){

        // Notificações
        $SQLnoti= "select * from  notificacoes where lido='nao' and tipo='chamados' and usuario_id='".$_SESSION['usuarioID']."'";
        $SQLnoti = $conn->prepare($SQLnoti);
        $SQLnoti->execute();
        $totalnoti = $SQLnoti->rowCount();

        if($totalnoti>0){
            while($tudo= $SQLnoti->fetch()){

                $SQLnotiler= "update notificacoes set lido='sim' where id='".$tudo['id']."'";
                $SQLnotiler = $conn->prepare($SQLnotiler);
                $SQLnotiler->execute();

            }
        }

    }

}else{$tipo='tudo';}

?>
    <main>
     <center>
      <h1>Histórico do Painel</h1>
        <div class="recent-orders">
        <div class="scroller">
          <table>
                        <?php
                        if($tipo=='tudo'){
                            $SQLUPUser= "SELECT * FROM notificacoes where usuario_id =  '".$usuario['id_usuario']."' ORDER BY id desc LIMIT 15";
                        }else{
                            $SQLUPUser= "SELECT * FROM notificacoes where usuario_id =  '".$usuario['id_usuario']."' and tipo='".$tipo."' ORDER BY id desc LIMIT 15";
                        }
                        $SQLUPUser = $conn->prepare($SQLUPUser);
                        $SQLUPUser->execute();

                        // output data of each row
                        if (($SQLUPUser->rowCount()) > 0) {
                            while($noti = $SQLUPUser->fetch()){

                                switch($noti['tipo']){
                                    case 'fatura':$tipo='Fatura';$class='label label-success';$info='Visualizar';break;
                                    case 'conta':$tipo='Conta';$class='label label-warning';$info=$noti['info_outros'];break;
                                    case 'revenda':$tipo='Revenda';$class='label label-danger';$info=$noti['info_outros'];break;
                                    case 'subrevenda':$tipo='Revenda-SUB';$class='label label-primary';$info='Sobre a Revenda';break;
                                    case 'usuario':$tipo='Usúario VPN';$class='label label-primary';$info='Sobre Suas Contas';break;
                                    case 'outros':$tipo='Outros';$class='label label-primary';$info=$noti['info_outros'];break;
                                    case 'chamados':$tipo='Chamado/Suporte';$class='label label-primary';$info=$noti['info_outros'];break;
                                    default:$tipo='erro';break;
                                }

                                //Datas

                                $datacriado=$noti['data'];
                                $dataconvcriado = substr($datacriado, 0, 10);
                                $partes = explode("-", $dataconvcriado);
                                $ano = $partes[0];
                                $mes = $partes[1];
                                $dia = $partes[2];


                                ?>


                                <tr>
                                    <td>
                                     <div class="serlist">
                                    <b>Tipo:</b>
                                    <?php echo $tipo;?>
                                    <br>
                                    <b>Data:</b>
                                    <?php echo $dia;?>/<?php echo $mes;?>/<?php echo $ano;?>
                                    <br>
                                    <?php if($noti['linkfatura']=='Admin'){?>
                                    <b>Detalhes:</b><br>
                                    <span>Administrador</span>
                                    <?php }else{ if($tipo=='Fatura'){?>
                                    <?php }else{?>
                                    <b>Detalhes:</b><br>
                                    <span class="<?php echo $class;?>"><?php echo $info;?></span>
                                    <br>
                                    <?php } } ?>
                                    <b>Detalhes:</b>
                                    <br>
                                    <?php echo $noti['mensagem'];?></td>
                              </div>
                           </tr>
                       <?php } }else{ ?>
                      <?php }?>
                    </table>
                   </div>
                  </div>
                 </main>
                 
<style>
b {
  color: #1E90FF;
}
</style>
      <!----------------- END OF MAIN -------------------->
      <div class="right">
        <div class="top">
          <button id="menu-btn">
            <span class="material-icons-sharp"><ion-icon name="menu-sharp"></ion-icon></span>
          </button>
          <div class="theme-toggler">
            <span class="material-icons-sharp active">light_mode</span>
            <span class="material-icons-sharp">dark_mode</span>
          </div>
          <div class="profile">
            <div class="info">
              <p>Olá, <b><?php echo strtoupper($usuario['nome']);?></b></p>
              <small class="text-muted"><?php echo $tipouser;?></small>
            </div>
            <div class="profile-photo">
             <a href="/SubMenu.php?page=admin/dados">
              <img src="/PNG/<?php echo $avatarusu;?>" /></a>
            </div>
          </div>
        </div>
        <script type="text/javascript" src="/SYSTEM/sort-table.js"></script>
        <script src="/CSS/index.js"></script>