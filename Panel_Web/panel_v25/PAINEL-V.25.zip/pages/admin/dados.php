<?php

if(isset($_GET['char'])){

    $novochar=$_GET['char'];

    switch($novochar){
        case 1:$char=1;break;
        case 2:$char=2;break;
        case 3:$char=3;break;
        case 4:$char=4;break;
        case 5:$char=5;break;
        default:$char=0;break;
    }

    if($char==0){
        echo '<script type="text/javascript">';
        echo 	'alert("Ocorreu um erro na seleção !");';
        echo	'window.location="../SubMenu.php?page=admin/dados"';
        echo '</script>';
        exit;

    }

    if(($char==5)and($usuario['tipo']<>'revenda')){
        echo '<script type="text/javascript">';
        echo 	'alert("Você não é um revendedor!");';
        echo	'window.location="../SubMenu.php?page=admin/dados"';
        echo '</script>';
        exit;

    }


    $SQLDelSSH = "update usuario set avatar='".$char."' WHERE id_usuario = '".$usuario['id_usuario']."'  ";
    $SQLDelSSH = $conn->prepare($SQLDelSSH);
    $SQLDelSSH->execute();

    echo '<script type="text/javascript">';
    echo 	'alert("Avatar atualizado com sucesso!");';
    echo	'window.location="../../SubMenu.php?page=admin/dados"';
    echo '</script>';


}

switch($usuario['tipo']){
    case 'vpn':$tipousuario='Usuário VPN';break;
    case 'revenda':$tipousuario='Revendedor';break;
    default:$tipousuario='erro';break;
}
if(($usuario['tipo']=='revenda')&&($usuario['subrevenda']=='sim')){
    $tipousuario='Sub Revendedor';
}

if(($usuario['tipo']=='revenda')&&($usuario['subrevenda']=='nao')){
    $SQLSubrevendedores= "select * from usuario WHERE id_mestre = '".$_SESSION['usuarioID']."' and tipo='revenda' and subrevenda='sim' ";
    $SQLSubrevendedores = $conn->prepare($SQLSubrevendedores);
    $SQLSubrevendedores->execute();
    $todossubrevendedores=$SQLSubrevendedores->rowCount();

    if (($SQLSubrevendedores->rowCount()) > 0) {

        while($subrow = $SQLSubrevendedores->fetch()) {
            $quantidade_ssh_subs=0;
            $SQLSubSSHsubs= "select * from usuario_ssh WHERE id_usuario = '".$subrow['id_usuario']."'  ";
            $SQLSubSSHsubs = $conn->prepare($SQLSubSSHsubs);
            $SQLSubSSHsubs->execute();
            $quantidade_ssh_subs += $SQLSubSSHsubs->rowCount();

            $sshsubs=$SQLSubSSHsubs->rowCount();


            $SQLSubUSUARIOSsubs= "select * from usuario WHERE id_mestre = '".$subrow['id_usuario']."'  ";
            $SQLSubUSUARIOSsubs = $conn->prepare($SQLSubUSUARIOSsubs);
            $SQLSubUSUARIOSsubs->execute();
            $quantidade_USUARIOS_subs += $SQLSubUSUARIOSsubs->rowCount();
            $sshsubs132=$SQLSubUSUARIOSsubs->rowCount();
            if (($SQLSubUSUARIOSsubs->rowCount()) > 0) {
                while($subrow2 = $SQLSubUSUARIOSsubs->fetch()) {
                    $SQLSubSSHsubs123= "select * from usuario_ssh WHERE id_usuario = '".$subrow2['id_usuario']."'  ";
                    $SQLSubSSHsubs123 = $conn->prepare($SQLSubSSHsubs123);
                    $SQLSubSSHsubs123->execute();
                    $quantidade_ssh_subs += $SQLSubSSHsubs123->rowCount();
                }

            }




        }


    }



}

?>
<script>
    function selecionachar(id){
        decisao = confirm("Confirme o novo Avatar!");
        if (decisao){
            window.location.href='../SubMenu.php?page=admin/dados&char='+id;
        } else {

        }


    }
</script>
<main>
 <center><h1>Informações do Painel</h1></center>
 
<div class="cards">
<div class="sales">
 <div class="linha">
 <center>  
 <img class="profile-photo" style="width: 70px; height: 70px;" src="../../PNG/<?php echo $avatarusu;?>">
 
 <h2><?php echo $usuario['nome'];?></h2>
  <p>Tipo: <?php echo $tipousuario;?></p>
   <p>Criado: <?php echo date('d/m/Y', strtotime($usuario['data_cadastro']));?></p>
   </div>
    <center> 
    <br>
  </div>
 </div>
 
 
<div class="cards">
  <div class="tab">
   <center> <button class="btnn" onclick="openCity(event, 'Event')"><b style="color: #fff;">↓ Alterar Avatar ↓</b></button>
 </center>
   <div id="Event" class="tabcontent">
    <div class="profil">

  <img onclick="selecionachar(1);" class="profile-photo" src="../../PNG/profile-1.png" alt="User profile picture">
  
  <img onclick="selecionachar(2);" class="profile-photo" src="../../PNG/profile-2.png" alt="User profile picture">

  <img onclick="selecionachar(3);" class="profile-photo"src="../../PNG/profile-3.png" alt="User profile picture">

  <img onclick="selecionachar(4);" class="profile-photo" src="../../PNG/profile-4.png" alt="User profile picture">

 </div>
  </div>
   </div>
  <center><p style="font-weight: bold;">Selecione a foto de perfil que deseja!</p></center>
  </div>
</main>
      <!----------------- END OF MAIN -------------------->
      <div class="right">
        <div class="top">
          <button id="menu-btn">
            <span class="material-icons-sharp"><ion-icon name="menu-sharp"></ion-icon></span>
          </button>
          <div class="theme-toggler">
            <span class="material-icons-sharp active">light_mode</span>
            <span class="material-icons-sharp">dark_mode</span>
          </div>
          <div class="profile">
            <div class="info">
              <p>Olá, <b><?php echo strtoupper($usuario['nome']);?></b></p>
              <small class="text-muted"><?php echo $tipouser;?></small>
            </div>
            <div class="profile-photo">
              <img src="/PNG/<?php echo $avatarusu;?>" />
            </div>
          </div>
        </div>
 
 <center><h2>Editar Perfil do Painel</h2></center>
  <div class="sales-analytics">
   <div class="item online">
    <form  class="form-horizontal" role="form" id="form" name="form" action="pages/admin/alterar.php" method="post">
    <div class="bord">

 <b style="font-size: 12pt;">Nome</b>
  <input type="text" class="caa" minlength="4" id="nome" name="nome" value="<?php echo $usuario['nome'];?>" placeholder="Nome" required="required">
<br><br>

 <b style="font-size: 12pt;">E-Mail</b>
  <input type="text" class="caa" minlength="4" id="email" name="email" value="<?php echo $usuario['email'];?>" placeholder="E-Mail" required="required">
<br><br>

 <b style="font-size: 12pt;">Celular</b>
  <input type="text" class="caa" minlength="11" id="celular" name="celular" value="<?php echo $usuario['celular'];?>" placeholder="Celular" required="required">
<br><br>

 <b style="font-size: 12pt;">Senha</b>
  <input type="password" min="4" class="caa" name="senha" data-minlength="4" placeholder="Digite a Senha Nova"  required="required" value="<?php echo $usuario['senha'];?>">
      <br><br>
      
     <button type="submit" class="btn">Salvar Dados</button>
     <button type="reset" class="bt">Resetar</button>
    </form>
   </div>
  </div>
 </div>
  <script type="text/javascript" src="/SYSTEM/sort-table.js"></script>
   <script src="/CSS/index.js"></script>
    <script src="/CSS/inde.js"></script>