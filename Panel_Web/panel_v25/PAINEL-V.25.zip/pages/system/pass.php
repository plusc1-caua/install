<?php $pass = 'caua';?>
