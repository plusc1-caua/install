<?php
include("MenuSub.php")
?>
    <main>
     <center>
      <h1>Lista Revenda Criado</h1>
        <div class="recent-orders">
         <div class="scroller">
          <table class="js-sort-table" id="customers">
                        <tr>
                            
                            <th>
                            NOME
                            </th>
                               
                            <th>
                            STATUS
                            </th>
                                             
                            <th>
                            LOGIN
                            </th>
                            
                            <th>
                            SENHA
                            </th>
                            
                            <th>
                            CRIADO
                            </th>
                            
                            <th>
                            USADO
                            </th>
                            
                            <th>
                            SERVER
                            </th>
                            
                            <th>
                            EDITAR
                            </th>
                            
                        </tr>
                        <?php



                        $SQLUsuario = "SELECT * FROM usuario   where  tipo = 'revenda' ORDER BY ativo ";
                        $SQLUsuario = $conn->prepare($SQLUsuario);
                        $SQLUsuario->execute();


                        // output data of each row
                        if (($SQLUsuario->rowCount()) > 0) {

                        while($row = $SQLUsuario->fetch())


                        {
                        $class = "class='btn-sm btn-danger'";
                        $status="";
                        $color = "";
                        $contas = 0;
                        $servidores = 0;
                        if($row['ativo']== 1){
                            $status="Ativo";
                            $sts ="on";
                        }else{
                            $status="Inativo";
                            $color = "";
                            $sts ="off";
                        }


                        $SQLContasSSH = "select * from usuario_ssh WHERE id_usuario = '".$row['id_usuario']."'";
                        $SQLContasSSH = $conn->prepare($SQLContasSSH);
                        $SQLContasSSH->execute();
                        $contas += $SQLContasSSH->rowCount();

                        $SQLServidores = "select * from acesso_servidor WHERE id_usuario = '".$row['id_usuario']."'";
                        $SQLServidores = $conn->prepare($SQLServidores);
                        $SQLServidores->execute();
                        $servidores += $SQLServidores->rowCount();

                        $total_acesso_ssh = 0;
                        $SQLAcessoSSH = "SELECT sum(acesso) AS quantidade  FROM usuario_ssh where id_usuario='".$row['id_usuario']."' ";
                        $SQLAcessoSSH = $conn->prepare($SQLAcessoSSH);
                        $SQLAcessoSSH->execute();
                        $SQLAcessoSSH = $SQLAcessoSSH->fetch();
                        $total_acesso_ssh += $SQLAcessoSSH['quantidade'];


                        $SQLUserSub = "select * from usuario WHERE id_mestre = '".$row['id_usuario']."'";
                        $SQLUserSub = $conn->prepare($SQLUserSub);
                        $SQLUserSub->execute();

                        if (($SQLUserSub->rowCount()) > 0) {

                            while($rowS = $SQLUserSub->fetch()) {
                                $SQLContasSSH = "select * from usuario_ssh WHERE id_usuario = '".$rowS['id_usuario']."'";
                                $SQLContasSSH = $conn->prepare($SQLContasSSH);
                                $SQLContasSSH->execute();
                                $contas += $SQLContasSSH->rowCount();

                                $SQLAcessoSSH = "SELECT sum(acesso) AS quantidade  FROM usuario_ssh where id_usuario='".$rowS['id_usuario']."' ";
                                $SQLAcessoSSH = $conn->prepare($SQLAcessoSSH);
                                $SQLAcessoSSH->execute();
                                $SQLAcessoSSH = $SQLAcessoSSH->fetch();
                                $total_acesso_ssh += $SQLAcessoSSH['quantidade'];


                            }
                        }

                        if($row['subrevenda']=='sim'){
                            $subrev='Sim';
                        }else{
                            $subrev='Não';
                        }





                        ?>
                                        <tr <?php echo $color; ?>>

                      <td>
                      <?php echo $row['nome'];?>
                      </td>
                         
                      <td>
                      <div class="<?php echo $sts;?>">
                      <?php echo $status; ?>
                      </div>
                      </td>
                                              
                      <td>
                      <?php echo $row['login'];?>
                      </td>
                      
                      <td>
                      <?php echo $row['senha'];?>
                      </td>
                      
                      <td>
                      <?php echo $contas;?>
                      </td>
                      
                      <td>
                      <?php echo $total_acesso_ssh;?>
                      </td>
                      
                      <td>
                      <?php echo $servidores;?>
                      </td>
                   
                    <td>
                     <a href="/admin/MenuSub.php?page=usuario/perfil&id_usuario=<?php echo $row['id_usuario'];?>">
                     <button class="botao2">
                     <ion-icon name="brush"></ion-icon>
                     </button>
                     </a>
                     </td>
                         
                      </tr>


                            <?php }
                            }


                            ?>
                            
                     </table>
                   </div>
                 </div>
                 </main>
      <!----------------- END OF MAIN -------------------->
      <div class="right">
        <div class="top">
          <button id="menu-btn">
            <span class="material-icons-sharp"><ion-icon name="menu-sharp"></ion-icon></span>
          </button>
          <div class="theme-toggler">
            <span class="material-icons-sharp active">light_mode</span>
            <span class="material-icons-sharp">dark_mode</span>
          </div>
          <div class="profile">
            <div class="info">
              <p>Olá, <b><?php echo strtoupper($administrador['nome']);?></b></p>
              <small class="text-muted">Administrador</small>
            </div>
            <div class="profile-photo">
             <a href="/admin/MenuSub.php?page=admin/dados">
              <img src="/PNG/admin.png" /></a>
            </div>
          </div>
        </div>
        <script type="text/javascript" src="/SYSTEM/sort-table.js"></script>
        <script src="/CSS/index.js"></script>