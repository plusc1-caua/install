<?php
include("MenuSub.php")
?>
      <main>
        <center>
        <h1>Criar Revenda</h1>
        </center>
        <form data-toggle="validator" action="pages/usuario/adicionar_exe.php" method="POST" role="form">
        <div class="cards">
          
         <div class="textfield">
        <h3>Nome</h3>
       <input type="text" name="nome" id="nome" class="form-control" minlength="4" placeholder="Digite Nome Painel" required>
            </div>
            
         <div class="textfield">
        <h3>Celular</h3>
       <input type="text" name="celular" id="celular" placeholder="Telefone Contato" value="(11) 99999-9999" class="form-control" minlength="4" maxlength="16" required>
            </div>
            
         <div class="textfield">
        <h3>Usuário</h3>
       <input type="text" name="login" id="login" class="form-control" minlength="4" placeholder="Usuário de acesso" required="">
            </div>
            
         <div class="textfield">
        <h3>Senha</h3>
       <input type="password" min="4" max="32" class="form-control"  name="senha" data-minlength="4" id="senha" placeholder="Senha de acesso" required>
            </div>
        
        <div style="display: none;">
        <fieldset>
         <input type="radio" class="check" id="radio1" name="tipo" value="revenda" checked>
        </fieldset>
          </div>

         <center>
       <button name="botaologin" class="btn-login" type="submit">Criar</button>
       <button name="botaologin" class="btn-login" type="reset">Limpar</button>
         </center>
          </div>
         </form>
       </main>
      <!----------------- END OF MAIN -------------------->
      <div class="right">
        <div class="top">
          <button id="menu-btn">
            <span class="material-icons-sharp"><ion-icon name="menu-sharp"></ion-icon></span>
          </button>
          <div class="theme-toggler">
            <span class="material-icons-sharp active">light_mode</span>
            <span class="material-icons-sharp">dark_mode</span>
          </div>
          <div class="profile">
            <div class="info">
              <p>Olá, <b><?php echo strtoupper($administrador['nome']);?></b></p>
              <small class="text-muted">Administrador</small>
            </div>
            <div class="profile-photo">
             <a href="/admin/MenuSub.php?page=admin/dados">
              <img src="/PNG/admin.png" /></a>
            </div>
          </div>
        </div>
    <script src="/CSS/index.js"></script>