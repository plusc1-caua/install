<?php
require_once("../pages/system/funcoes.php");
require_once("../pages/system/seguranca.php");
require_once("../pages/system/config.php");
require_once("../pages/system/classe.ssh.php");

protegePagina("admin");
if( $_SESSION['tipo'] == "user"){
    expulsaVisitante();
}


$data_atual = date("Y-m-d");

$SQLAdministrador = "SELECT * FROM admin WHERE id_administrador = '".$_SESSION['usuarioID']."'";
$SQLAdministrador = $conn->prepare($SQLAdministrador);
$SQLAdministrador->execute();
$administrador = $SQLAdministrador->fetch();

//Carrega qtd contas ssh do sistema

$SQLUsuario_sshSUSP = "select * from usuario_ssh WHERE status='2' ";
$SQLUsuario_sshSUSP = $conn->prepare($SQLUsuario_sshSUSP);
$SQLUsuario_sshSUSP->execute();
$ssh_susp_qtd += $SQLUsuario_sshSUSP->rowCount();

$SQLContasSSH = "SELECT * FROM usuario_ssh ";
$SQLContasSSH = $conn->prepare($SQLContasSSH);
$SQLContasSSH->execute();
$contas_ssh = $SQLContasSSH->rowCount();


$total_acesso_ssh = 0;
$SQLAcessoSSH = "SELECT sum(acesso) AS quantidade  FROM usuario_ssh  ";
$SQLAcessoSSH = $conn->prepare($SQLAcessoSSH);
$SQLAcessoSSH->execute();
$SQLAcessoSSH = $SQLAcessoSSH->fetch();
$total_acesso_ssh += $SQLAcessoSSH['quantidade'];

$total_acesso_ssh_online = 0;
$SQLAcessoSSH = "SELECT sum(online) AS quantidade  FROM usuario_ssh  ";
$SQLAcessoSSH = $conn->prepare($SQLAcessoSSH);
$SQLAcessoSSH->execute();
$SQLAcessoSSH = $SQLAcessoSSH->fetch();
$total_acesso_ssh_online += $SQLAcessoSSH['quantidade'];


//carrega qtd de todos os usuarios do sistema
$SQLUsuarios = "SELECT * FROM usuario ";
$SQLUsuarios = $conn->prepare($SQLUsuarios);
$SQLUsuarios->execute();
$all_usuarios_qtd = $SQLUsuarios->rowCount();

//carrega qtd de todos os usuarios do sistema SSH
$SQLVPN = "SELECT * FROM usuario  where tipo='vpn' ";
$SQLVPN = $conn->prepare($SQLVPN);
$SQLVPN->execute();
$all_usuarios_vpn_qtd = $SQLVPN->rowCount();

$SQLVPN = "SELECT * FROM usuario  where tipo='vpn' and ativo='2' ";
$SQLVPN = $conn->prepare($SQLVPN);
$SQLVPN->execute();
$all_usuarios_vpn_qtd_susp = $SQLVPN->rowCount();

//carrega qtd de todos os usuarios do sistema SSH
$SQLRevenda = "SELECT * FROM usuario  where tipo='revenda' ";
$SQLRevenda = $conn->prepare($SQLRevenda);
$SQLRevenda->execute();
$all_usuarios_revenda_qtd = $SQLRevenda->rowCount();
//carrega qtd de todos os usuarios do sistema SSH
$SQLRevenda = "SELECT * FROM usuario  where tipo='revenda' and ativo='2'";
$SQLRevenda = $conn->prepare($SQLRevenda);
$SQLRevenda->execute();
$revenda_qtd_susp = $SQLRevenda->rowCount();

//carrega qtd de servidores
$SQLServidor = "SELECT * FROM servidor ";
$SQLServidor = $conn->prepare($SQLServidor);
$SQLServidor->execute();
$servidor_qtd = $SQLServidor->rowCount();

// arquivos download
$SQLArquivos= "select * from  arquivo_download";
$SQLArquivos = $conn->prepare($SQLArquivos);
$SQLArquivos->execute();
$todosarquivos = $SQLArquivos->rowCount();
// Faturas
$SQLfaturas= "select * from  fatura where status='pendente'";
$SQLfaturas = $conn->prepare($SQLfaturas);
$SQLfaturas->execute();
$faturas = $SQLfaturas->rowCount();
// Notificações
$SQLnoti= "select * from  notificacoes where lido='nao' and admin='sim'";
$SQLnoti = $conn->prepare($SQLnoti);
$SQLnoti->execute();
$totalnoti = $SQLnoti->rowCount();
// Notificações fatura
$SQLnoti2= "select * from  notificacoes where lido='nao' and tipo='fatura' and admin='sim'";
$SQLnoti2= $conn->prepare($SQLnoti2);
$SQLnoti2->execute();
$totalnoti_fatura = $SQLnoti2->rowCount();
// Notificações chamados
$SQLnoti3= "select * from  notificacoes where lido='nao' and tipo='chamados' and admin='sim'";
$SQLnoti3= $conn->prepare($SQLnoti3);
$SQLnoti3->execute();
$totalnoti_chamados = $SQLnoti3->rowCount();

//Todos os chamados subRevendedores e usuarios do revendedor
$SQLchamadoscli2= "select * from  chamados where status='resposta' and id_mestre=0";
$SQLchamadoscli2= $conn->prepare($SQLchamadoscli2);
$SQLchamadoscli2->execute();
$all_chamados += $SQLchamadoscli2->rowCount();
//Todos os chamados subRevendedores e usuarios do revendedor
$SQLchamadoscli= "select * from  chamados where status='aberto' and id_mestre=0";
$SQLchamadoscli= $conn->prepare($SQLchamadoscli);
$SQLchamadoscli->execute();
$all_chamados += $SQLchamadoscli->rowCount();



?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Painel Web</title>
    <!-- MATERIAL CDN -->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Sharp" rel="stylesheet" />
	<link rel="icon" type="image/png" sizes="18x18" href="/PNG/inicial/avatar.svg">
    <script src="https://unpkg.com/ionicons@5.1.2/dist/ionicons.js"></script>
    <script src="http://code.jquery.com/jquery-latest.js"></script>
    <!-- STYLESHEET -->
    <link rel="stylesheet" href="/CSS/style.css" />
    <link rel="stylesheet" href="/CSS/mains.css" />
    <link rel="stylesheet" href="/SYSTEM/select.css" />
    <link rel="stylesheet" href="/SYSTEM/config.css" />
    <link rel="stylesheet" href="/SYSTEM/config2.css" />
    <link rel="stylesheet" href="/SYSTEM/config3.css" />
    <link rel="stylesheet" href="/SYSTEM/config4.css" />
    <link rel="stylesheet" href="/SYSTEM/login-add.css" />
    
  </head>
  <body>
    <div class="container">
    <script>
        function usuariosonline()
        {

        // Requisição
        $.post('pages/ssh/online_home.php?requisicao=1',
            function (resposta) {
                //Adiciona Efeito Fade
                $("#usuarioson").fadeOut("slow").fadeIn('slow');
                // Limpa
                $('#usuarioson').empty();
                // Exibe
                $('#usuarioson').append(resposta);
            });
    }
    // Intervalo para cada Chamada
    setInterval("usuariosonline()", 10000);

    // Após carregar a Pagina Primeiro Requisito
    $(function() {
        // Requisita Função acima
        usuariosonline();
    });
</script>
<script>
    function atualizar()
    {
        // Fazendo requisição AJAX
        $.post('pages/ssh/online_home.php?requisicao=2',
            function (online) {
                // Exibindo frase
                $('#online_nav').html(online);
                $('#online').html(online);

            }, 'JSON');
    }
    // Definindo intervalo que a função será chamada
    setInterval("atualizar()", 1000);
    // Quando carregar a página
    $(function() {
        // Faz a primeira atualização
        atualizar();
    });
</script>

<script>
    //paste this code under head tag or in a seperate js file.
    // Wait for window load
    $(window).load(function() {
        // Animate loader off screen
        $(".se-pre-con").fadeOut('slow');;
    });
</script>
      <aside>
        <div class="top">
          <div class="logo">
            <img src="/PNG/logo.png" />
            <h2 cla>C1-<span class="danger">PLUS</span></h2>
          </div>
          <div class="close" id="close-btn">
            <span class="material-icons-sharp">close</span>
          </div>
        </div>
        <div class="sidebar">
          <a href="/admin/home.php" class="active">
            <span class="material-icons-sharp">grid_view</span>
            <h3>Dashboard</h3>
          </a>
          
          <a href="/admin/user_erro.php">
            <span class="material-icons-sharp"><ion-icon name="bug"></ion-icon></span>
            <h3>User com Erro</h3>
          </a>
          
          <a href="/admin/add_rev.php">
            <span class="material-icons-sharp"><ion-icon name="person-add"></ion-icon></span>
            <h3>ADD Revenda</h3>
          </a>
                    
          <a href="/admin/rev_lista.php">
            <span class="material-icons-sharp"><ion-icon name="person"></ion-icon></span>
            <h3>Listar Revenda</h3>
            <span class="message-count"><?php echo $all_usuarios_qtd; ?></span>
          </a>
          
          <a href="/admin/add_server_rev.php">
            <span class="material-icons-sharp"><ion-icon name="file-tray-stacked"></ion-icon></span>
            <h3>ADD Acessos Revenda</h3>
          </a>          
                    
          <a href="/admin/rev_editar.php">
            <span class="material-icons-sharp"><ion-icon name="create"></ion-icon></span>
            <h3>Editar Revenda</h3>
          </a>          

          <a href="/admin/cadastro.php">
            <span class="material-icons-sharp"><ion-icon name="add-circle"></ion-icon></span>
            <h3>Cadastro</h3>
          </a>
          
          <a href="/admin/add_server.php">
            <span class="material-icons-sharp"><ion-icon name="server"></ion-icon></span>
            <h3>ADD Servidor</h3>
          </a>
          
          <a href="/admin/server_lista.php">
            <span class="material-icons-sharp"><ion-icon name="albums"></ion-icon></span>
            <h3>Listar Servidor</h3>
            <span class="message-count"><?php echo $servidor_qtd; ?></span>
          </a>
          
          <a href="/admin/MenuSub.php?page=admin/dados">
            <span class="material-icons-sharp"><ion-icon name="construct"></ion-icon></span>
            <h3>Configurações</h3>
          </a>

          <a href="/admin/sair.php" class="active">
            <span class="material-icons-sharp"><ion-icon name="log-out-sharp"></ion-icon></span>
            <h3>Log Out</h3>
         </a>
       </div>
     </aside>

        <?php


        if(isset($_GET["page"])){
            $page = $_GET["page"];
            if($page and file_exists("pages/".$page.".php")) {
                include("pages/".$page.".php");
            } else {
                include("./pages/li.php");
            }
        }else{
            include("./pages/li.php");
        }


        ?>
  </body>
</html>
