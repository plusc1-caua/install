<?php
include("MenuSub.php")
?>
<?php

// Usados

$qtddoserverusado = 0;

$SQLusuariosdele = "SELECT * FROM acesso_servidor";
$SQLusuariosdele = $conn->prepare($SQLusuariosdele);
$SQLusuariosdele->execute();

if ($SQLusuariosdele->rowCount() > 0) {
    while ($usuariosdele = $SQLusuariosdele->fetch()) {


        $SQLcontaqtdsshusadodele = "SELECT sum(acesso) as acessosdosserversusados2 FROM usuario_ssh where id_usuario = '" . $usuariosdele['id_usuario'] . "'";
        $SQLcontaqtdsshusadodele = $conn->prepare($SQLcontaqtdsshusadodele);
        $SQLcontaqtdsshusadodele->execute();

        $qtdusadosdele = $SQLcontaqtdsshusadodele->fetch();

        $qtddoserverusado += $qtdusadosdele['acessosdosserversusados2'];

        //Select sub deles

        $SQLusuariossubdele = "SELECT * FROM usuario where id_mestre = '" . $usuariosdele['id_usuario'] . "'";
        $SQLusuariossubdele = $conn->prepare($SQLusuariossubdele);
        $SQLusuariossubdele->execute();

        if ($SQLusuariossubdele->rowCount() > 0) {
            while ($usuariossubdele = $SQLusuariossubdele->fetch()) {
                $SQLcontaqtdsshusado = "SELECT sum(acesso) as acessosdosserversusados FROM usuario_ssh where id_usuario = '" . $usuariossubdele['id_usuario'] . "'";
                $SQLcontaqtdsshusado = $conn->prepare($SQLcontaqtdsshusado);
                $SQLcontaqtdsshusado->execute();

                $qtdusados = $SQLcontaqtdsshusado->fetch();

                $qtddoserverusado += $qtdusados['acessosdosserversusados'];
            }
        }
    }
}




// Todos Acessos

$todosacessos = 0;

$SQLqtdserveracessos2 = "SELECT sum(qtd) as tudo FROM  acesso_servidor";
$SQLqtdserveracessos2 = $conn->prepare($SQLqtdserveracessos2);
$SQLqtdserveracessos2->execute();

$totalacessf = $SQLqtdserveracessos2->fetch();

$todosacessos += $totalacessf['tudo'];


//Disponiveis
$disponiveis = $todosacessos - $qtddoserverusado;


//Calculo Porcentagem

$porcent = ($qtddoserverusado / $todosacessos) * 100; // %

$resultado = $porcent;

$valor_porce = round($resultado);





if (($valor_porce >= 70) and ($valor_porce < 90)) {
    $sucessobar = "warning";
    $bgbar = "warning";
} elseif ($valor_porce >= 90) {
    $sucessobar = "danger";
    $bgbar = "danger";
} else {
    $sucessobar = "success";
    $bgbar = "success";
}


?>
    <main>
     <center>
      <h1>Editar Revenda Criado</h1>
        <div class="recent-orders">
         <div class="scroller">
          <table class="js-sort-table" id="customers">
            <thead>
                        <tr>
                            
                            <th>
                            SERVER
                            </th>
                               
                            <th>
                            NOME
                            </th>
                                             
                            <th>
                            USADO
                            </th>
                            
                            <th>
                            CRIADO
                            </th>
                            
                            <th>
                            VALIDO
                            </th>
                            
                            <th>
                            LIMITE
                            </th>
                            
                            <th>
                            EDITAR
                            </th>
                            
                        </tr>
                        </thead>
                        <tbody>

                                    <?php

                                    $SQLServidorac = "select * from acesso_servidor";
                                    $SQLServidorac = $conn->prepare($SQLServidorac);
                                    $SQLServidorac->execute();

                                    // output data of each row
                                    if (($SQLServidorac->rowCount()) > 0) {

                                        while ($serveacesso = $SQLServidorac->fetch()) {
                                            $Servidor = "select * from servidor where id_servidor='" . $serveacesso['id_servidor'] . "'";
                                            $Servidor = $conn->prepare($Servidor);
                                            $Servidor->execute();
                                            $row = $Servidor->fetch();

                                            $SQLcliennte = "select * from usuario WHERE id_usuario='" . $serveacesso['id_usuario'] . "' ";
                                            $SQLcliennte = $conn->prepare($SQLcliennte);
                                            $SQLcliennte->execute();
                                            $cliente = $SQLcliennte->fetch();

                                            $contas = 0;
                                            $total_acesso_ssh = 0;

                                            $SQLContasSSH = "select * from usuario_ssh WHERE id_usuario = '" . $serveacesso['id_usuario'] . "' and id_servidor='" . $serveacesso['id_servidor'] . "'";
                                            $SQLContasSSH = $conn->prepare($SQLContasSSH);
                                            $SQLContasSSH->execute();
                                            $contas += $SQLContasSSH->rowCount();


                                            $SQLAcessoSSH = "SELECT sum(acesso) AS quantidade  FROM usuario_ssh where id_usuario='" . $serveacesso['id_usuario'] . "' and id_servidor='" . $serveacesso['id_servidor'] . "'";
                                            $SQLAcessoSSH = $conn->prepare($SQLAcessoSSH);
                                            $SQLAcessoSSH->execute();
                                            $SQLAcessoSSH = $SQLAcessoSSH->fetch();
                                            $total_acesso_ssh += $SQLAcessoSSH['quantidade'];

                                            $SQLUserSub = "select * from usuario WHERE id_mestre = '" . $serveacesso['id_usuario'] . "' and subrevenda='nao'";
                                            $SQLUserSub = $conn->prepare($SQLUserSub);
                                            $SQLUserSub->execute();

                                            if (($SQLUserSub->rowCount()) > 0) {

                                                while ($rowS = $SQLUserSub->fetch()) {
                                                    $SQLContasSSH = "select * from usuario_ssh WHERE id_usuario = '" . $rowS['id_usuario'] . "'  and id_servidor='" . $serveacesso['id_servidor'] . "'";
                                                    $SQLContasSSH = $conn->prepare($SQLContasSSH);
                                                    $SQLContasSSH->execute();
                                                    $contas += $SQLContasSSH->rowCount();

                                                    $SQLAcessoSSH = "SELECT sum(acesso) AS quantidade  FROM usuario_ssh where id_usuario='" . $rowS['id_usuario'] . "'  and id_servidor='" . $serveacesso['id_servidor'] . "'";
                                                    $SQLAcessoSSH = $conn->prepare($SQLAcessoSSH);
                                                    $SQLAcessoSSH->execute();
                                                    $SQLAcessoSSH = $SQLAcessoSSH->fetch();
                                                    $total_acesso_ssh += $SQLAcessoSSH['quantidade'];
                                                }
                                            }

                                            $todosacessos2 = 0;

                                            $SQLqtdserveracessos2 = "SELECT sum(qtd) as todosacessos FROM  acesso_servidor where id_usuario = '" . $serveacesso['id_usuario'] . "' and id_servidor='" . $serveacesso['id_servidor'] . "' ";
                                            $SQLqtdserveracessos2 = $conn->prepare($SQLqtdserveracessos2);
                                            $SQLqtdserveracessos2->execute();

                                            $totalacess2 = $SQLqtdserveracessos2->fetch();

                                            $todosacessos2 += $totalacess2['todosacessos'];

                                            //Calculo Porcentagem

                                            $porcentagem = ($total_acesso_ssh / $todosacessos2) * 100; // %

                                            $resultado2 = $porcentagem;

                                            $valor_porcetage = round($resultado2);

                                            if ($valor_porcetage >= 100) {
                                                $valor_porcetage = 100;
                                            }
                                            if (($valor_porcetage >= 70) and ($valor_porcetage < 90)) {
                                                $sucessobar = "warning";
                                                $bgbar2 = "warning";
                                            } elseif ($valor_porcetage >= 90) {
                                                $sucessobar = "danger";
                                                $bgbar2 = "danger";
                                            } else {
                                                $sucessobar = "success";
                                                $bgbar2 = "success";
                                            }



                                            //Calcula os dias restante
                                            $data_atual = date("Y-m-d");
                                            $data_validade = $serveacesso['validade'];
                                            if ($data_validade > $data_atual) {
                                                $data1 = new DateTime($data_validade);
                                                $data2 = new DateTime($data_atual);
                                                $dias_acesso = 0;
                                                $diferenca = $data1->diff($data2);
                                                $ano = $diferenca->y * 364;
                                                $mes = $diferenca->m * 30;
                                                $dia = $diferenca->d;
                                                $dias_acesso = $ano + $mes + $dia;
                                            } else {
                                                $dias_acesso = 0;
                                            }

                                            $somapode = $serveacesso['qtd'] - $total_acesso_ssh;

                                            ?>
                                            <?php if ($cliente['subrevenda'] == 'nao') { ?>
                                        <tr <?php echo $color; ?>>

                      <td>
                      <?php echo $row['nome'];?>
                      </td>
                         
                      <td>
                      <?php echo $cliente['nome']; ?>
                      </td>
                                              
                      <td>
                      <?php echo $contas; ?>
                      </td>
                      
                      <td>
                      <?php echo $total_acesso_ssh; ?>
                      </td>
                      
                      <td>
                      <?php echo $dias_acesso . "  dias   "; ?>
                      </td>
                      
                      <td>
                      <?php echo $serveacesso['qtd']; ?>
                      </td>
                      
                    <td>
                     <a href="SubHome.php?page=usuario/perfil&id_usuario=<?php echo $row['id_usuario'];?>">
                     <button class="botao3">
                     <ion-icon name="copy"></ion-icon>
                     </button>
                     </a>
                     </td>
                      </tr>

                                    <?php }
                                }
                                ?>
                                    <?php } ?>
                        </tbody>
                     </table>
                   </div>
                 </div>
                 </main>
      <!----------------- END OF MAIN -------------------->
      <div class="right">
        <div class="top">
          <button id="menu-btn">
            <span class="material-icons-sharp"><ion-icon name="menu-sharp"></ion-icon></span>
          </button>
          <div class="theme-toggler">
            <span class="material-icons-sharp active">light_mode</span>
            <span class="material-icons-sharp">dark_mode</span>
          </div>
          <div class="profile">
            <div class="info">
              <p>Olá, <b><?php echo strtoupper($administrador['nome']);?></b></p>
              <small class="text-muted">Administrador</small>
            </div>
            <div class="profile-photo">
             <a href="/admin/MenuSub.php?page=admin/dados">
              <img src="/PNG/admin.png" /></a>
            </div>
          </div>
        </div>
        <script type="text/javascript" src="/SYSTEM/sort-table.js"></script>
        <script src="/CSS/index.js"></script>