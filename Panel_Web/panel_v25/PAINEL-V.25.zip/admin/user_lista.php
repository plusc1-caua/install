<?php
include("MenuSub.php")
?>
    <main>
     <center>
      <h1>Lista Usuarios Criado</h1>
        <div class="recent-orders">
         <div class="scroller">
          <table class="js-sort-table" id="customers">
                            <tr>
                <th>SERVER</th>
                <th>STATUS</th>
                <th>LOGIN</th>
                <th>SENHA</th>
                <th>VALIDO</th>
                <th>DONO</th>
                <th>OPCOES</th>
                            </tr>
                            <?php
                            $SQLSSH = "SELECT * FROM usuario_ssh , servidor  where usuario_ssh.id_servidor = servidor.id_servidor and  usuario_ssh.status <= '2' ORDER BY  usuario_ssh.status  ";
                            $SQLSSH = $conn->prepare($SQLSSH);
                            $SQLSSH->execute();


                            // output data of each row
                            if (($SQLSSH->rowCount()) > 0) {

                                while ($row = $SQLSSH->fetch()) {
                                    $class = "'";
                                    $status = "";
                                    $owner = "";
                                    $color = "";
                                    if ($row['status'] == 1) {
                                        $status = "Ativo";
                                        $sts ="on";
                                        $class = "'";
                                    } else if ($row['status'] == 2) {
                                        $status = "Inativo";
                                        $sts ="off";
                                        $color = "bgcolor=''";
                                    }
                                    if ($row['id_usuario'] == 0) {
                                        $owner = "Sistema";
                                    } else {

                                        $SQLRevendedor = "select * from usuario WHERE id_usuario = '" . $row['id_usuario'] . "'";
                                        $SQLRevendedor = $conn->prepare($SQLRevendedor);
                                        $SQLRevendedor->execute();
                                        $revendedor = $SQLRevendedor->fetch();

                                        $owner = $revendedor['login'];
                                    }
                                    //Calcula os dias restante
                                    $data_atual = date("Y-m-d ");
                                    $data_validade = $row['data_validade'];
                                    if ($data_validade > $data_atual) {
                                        $data1 = new DateTime($data_validade);
                                        $data2 = new DateTime($data_atual);
                                        $dias_acesso = 0;
                                        $diferenca = $data1->diff($data2);
                                        $ano = $diferenca->y * 364;
                                        $mes = $diferenca->m * 30;
                                        $dia = $diferenca->d;
                                        $dias_acesso = $ano + $mes + $dia;
                                    } else {
                                        $dias_acesso = 0;
                                    }
									$pegando = "SELECT * FROM usuario_ssh  where id_usuario_ssh='".$row['id_usuario_ssh']."'";
                                        $pegando = $conn->prepare($pegando);
                                        $pegando ->execute();
                                        $pegasenha = $pegando->fetch();


                                    ?>
                 <tr <?php echo $color; ?>>

                 <td><?php echo $row['nome']; ?></td>
                 <td><div class="<?php echo $sts;?>"><?php echo $status; ?></div></td>
                 <td><?php echo $row['login']; ?></td>
	             <td><?php echo $pegasenha['senha'];?></td>

                 <td>
                 <?php echo $dias_acesso . " dias "; ?>
                 </td>
                 
                 <td><?php echo $owner; ?></td>

                      <td>
                     <a href="MenuSub.php?page=ssh/editar&id_ssh=<?php echo $row['id_usuario_ssh']; ?>">
                     <button class="botao2">
                     <ion-icon name="brush"></ion-icon>
                     </button>
                     </a>
                      </td>
                          </tr>
                              
                                    <?php }
                                }


                               ?>
                    </table>
                   </div>
                  </div>
                 </main>
      <!----------------- END OF MAIN -------------------->
      <div class="right">
        <div class="top">
          <button id="menu-btn">
            <span class="material-icons-sharp"><ion-icon name="menu-sharp"></ion-icon></span>
          </button>
          <div class="theme-toggler">
            <span class="material-icons-sharp active">light_mode</span>
            <span class="material-icons-sharp">dark_mode</span>
          </div>
          <div class="profile">
            <div class="info">
              <p>Olá, <b><?php echo strtoupper($administrador['nome']);?></b></p>
              <small class="text-muted">Administrador</small>
            </div>
            <div class="profile-photo">
             <a href="/admin/MenuSub.php?page=admin/dados">
              <img src="/PNG/admin.png" /></a>
            </div>
          </div>
        </div>
        <script type="text/javascript" src="/SYSTEM/sort-table.js"></script>
        <script src="/CSS/index.js"></script>