<?php
include("MenuSub.php")
?>
    <main>
     <center>
      <h1>Lista Usuarios Erro</h1>
        <div class="recent-orders">
         <div class="scroller">
          <table class="js-sort-table" id="customers">
                        <tr>
                            
                            <th>
                            SERVER
                            </th>
                               
                            <th>
                            PROBLEMA
                            </th>
                                             
                            <th>
                            LOGIN
                            </th>
                            
                            <th>
                            VALIDADE
                            </th>
                            
                            <th>
                            OWNER
                            </th>
                            
                        </tr>
                            <?php
                            //lista
                            $SQLSSH = "SELECT * FROM usuario_ssh , servidor  where usuario_ssh.id_servidor = servidor.id_servidor and usuario_ssh.status > '2'";
                            $SQLSSH = $conn->prepare($SQLSSH);
                            $SQLSSH->execute();


                            // output data of each row
                            if (($SQLSSH->rowCount()) > 0) {

                                while ($row = $SQLSSH->fetch()) {
                                    $class = "class='btn-sm btn-danger'";
                                    $status = "";
                                    $erro = "";
                                    $owner = "";
                                    $color = "";


                                    if ($row['status'] == 1) {
                                        $status = "Ativo";
                                        $class = "class='btn-sm btn-primary'";
                                    } else if ($row['status'] == 2) {
                                        $status = "Suspenso";
                                        $color = "bgcolor=''";
                                    }
                                    if ($row['status'] == 3) {
                                        $erro = "Erro no id";
                                    }
                                    if ($row['apagar'] == 5) {
                                        $erro = "Erro ao deletar";
                                    }
                                    if ($row['id_usuario'] == 0) {
                                        $owner = "Sistema";
                                    } else {

                                        $SQLRevendedor = "select * from usuario WHERE id_usuario = '" . $row['id_usuario'] . "'";
                                        $SQLRevendedor = $conn->prepare($SQLRevendedor);
                                        $SQLRevendedor->execute();
                                        $revendedor = $SQLRevendedor->fetch();

                                        $owner = $revendedor['login'];
                                    }
                                    //Calcula os dias restante
                                    $data_atual = date("Y-m-d ");
                                    $data_validade = $row['data_validade'];
                                    if ($data_validade > $data_atual) {
                                        $data1 = new DateTime($data_validade);
                                        $data2 = new DateTime($data_atual);
                                        $dias_acesso = 0;
                                        $diferenca = $data1->diff($data2);
                                        $ano = $diferenca->y * 364;
                                        $mes = $diferenca->m * 30;
                                        $dia = $diferenca->d;
                                        $dias_acesso = $ano + $mes + $dia;
                                    } else {
                                        $dias_acesso = 0;
                                    }


                                    ?>

                      <tr <?php echo $color; ?>>

                      <td>
                      <?php echo $row['nome']; ?>
                      </td>
                         
                      <td>
                      <?php echo $erro; ?>
                      </td>
                                              
                      <td>
                      <?php echo $row['login']; ?>
                      </td>
                      
                      <td>
                      <?php echo $dias_acesso . "  dias   "; ?>
                      <?php echo date('d/m/Y', strtotime($row['data_validade'])); ?>
                      </td>
                      
                      <td>
                      <?php echo $owner; ?>
                      </td>
                      
                      </tr>

                                <?php }
                            }


                            ?>
                     </table>
                   </div>
                 </div>
                 </main>
      <!----------------- END OF MAIN -------------------->
      <div class="right">
        <div class="top">
          <button id="menu-btn">
            <span class="material-icons-sharp"><ion-icon name="menu-sharp"></ion-icon></span>
          </button>
          <div class="theme-toggler">
            <span class="material-icons-sharp active">light_mode</span>
            <span class="material-icons-sharp">dark_mode</span>
          </div>
          <div class="profile">
            <div class="info">
              <p>Olá, <b><?php echo strtoupper($administrador['nome']);?></b></p>
              <small class="text-muted">Administrador</small>
            </div>
            <div class="profile-photo">
             <a href="/admin/MenuSub.php?page=admin/dados">
              <img src="/PNG/admin.png" /></a>
            </div>
          </div>
        </div>
        <script type="text/javascript" src="/SYSTEM/sort-table.js"></script>
        <script src="/CSS/index.js"></script>