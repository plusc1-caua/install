
        <h1>Bem-Vindoª <?php echo strtoupper($administrador['nome']);?></h1>
        
        <div class="insights">
          <div class="sales">
            <span class="material-icons-sharp"><ion-icon name="person-circle-outline"></ion-icon></span>
            <div class="middle">
              <div class="left">
                <h2>Usuários Criado</h2>
               <a href="/admin/user_lista.php"><font color="#747fe1">Ver Todos</font></a>
              </div>
              <div class="progress">
                <svg>
                  <circle cx="38" cy="38" r="36"></circle>
                </svg>
                <div class="number">
                <h2><?php echo $total_acesso_ssh;?></h2>
                </div>
              </div>
            </div>
          </div>
          <!------------ END OF SALES -------------->
          <div class="expenses">
            <span class="material-icons-sharp"><ion-icon name="people-circle-outline"></ion-icon></span>
            <div class="middle">
              <div class="left">
                <h2>Usuários Online</h2>
               <a href=""><font color="#747fe1">10seg Update</font></a>
              </div>
              <div class="progress">
                <svg>
                  <circle cx="38" cy="38" r="36"></circle>
                </svg>
                <div class="number">
                <h1 id="online_nav"><?php echo $total_acesso_ssh_online; ?></h1>
                </div>
              </div>
            </div>
          </div>
          <!------------ END OF SALES -------------->
          <div class="income">
            <span class="material-icons-sharp"><ion-icon name="server"></ion-icon></span>
            <div class="middle">
              <div class="left">
                <h2>Servidor Disponível</h2>
               <a href="/admin/server_lista.php"><font color="#747fe1">Ver Todos</font></a>
              </div>
              <div class="progress">
                <svg>
                  <circle cx="38" cy="38" r="36"></circle>
                </svg>
                <div class="number">
                <h1><?php echo $servidor_qtd; ?></h1>
            </div>
           </div>
          </div>
          <!------------ END OF INCOME -------------->
        </div>
        <!------------ END OF INSIGHTS -------------->
      </div>
            
        <?php


        if(isset($_GET["page"])){
            $page = $_GET["page"];
            if($page and file_exists("".$page.".php")) {
                include("".$page.".php");
            } else {
                include("home3.php");
            }
        }else{
            include("home3.php");
        }

        ?>