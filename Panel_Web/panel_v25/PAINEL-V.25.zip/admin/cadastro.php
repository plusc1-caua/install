<?php
include("MenuSub.php")
?>
<main>
 <center><h1>Cadastro</h1></center>
 
<div class="cards">
<div class="sales">
 <div class="linha">
 <center>
  <p style="font-weight: bold;">OBS: O cadastro so é valido ao liberar um servidor, com a quantidade de dias acima de 1 dia. <br>0 dias desativa o cadastro!</p>
    <center>
  </div>
 </div>
   </div>
</main>
      <!----------------- END OF MAIN -------------------->
      <div class="right">
        <div class="top">
          <button id="menu-btn">
            <span class="material-icons-sharp"><ion-icon name="menu-sharp"></ion-icon></span>
          </button>
          <div class="theme-toggler">
            <span class="material-icons-sharp active">light_mode</span>
            <span class="material-icons-sharp">dark_mode</span>
          </div>
          <div class="profile">
            <div class="info">
              <p>Olá, <b><?php echo strtoupper($administrador['nome']);?></b></p>
              <small class="text-muted">Administrador</small>
            </div>
            <div class="profile-photo">
             <a href="/admin/MenuSub.php?page=admin/dados">
              <img src="/PNG/admin.png" /></a>
            </div>
          </div>
        </div>
 
 <center><h2>Liberar Cadastro</h2></center>
 
  <div class="sales-analytics">
   <div class="item online">
    <form role="form" action="pages/demo/configurar_exe.php" method="post">
     <div class="textfield">
 <center><b style="font-size: 12pt;">Selecione um Servidor para Cadastro.<br>Por cada conta Criada!</b></center>

  <select class="caa" name="servidor" id="servidor">
                  
                  <?php
    
	   
	$SQLAcessoSRV = "SELECT * FROM servidor WHERE  demo='1' LIMIT 1";
    $SQLAcessoSRV = $conn->prepare($SQLAcessoSRV);
    $SQLAcessoSRV->execute();
   

if (($SQLAcessoSRV->rowCount()) > 0) {
    // output data of each row
   $row_srv_principal = $SQLAcessoSRV->fetch();
		
		?>
        
	<option>Selecione um Servidor</option>
	
   <?php 
}

	
	$SQLAcessoSRV = "SELECT * FROM servidor WHERE   demo='0' ";
    $SQLAcessoSRV = $conn->prepare($SQLAcessoSRV);
    $SQLAcessoSRV->execute();
	

if (($SQLAcessoSRV->rowCount()) > 0) {
    // output data of each row
    while($row_srv = $SQLAcessoSRV->fetch()) {
		
		?>
        
	<option value="<?php echo $row_srv['id_servidor'];?>" > <?php echo $row_srv['nome'];?> </option>
	
   <?php }
}

?>	  				  
                </select>
              </div>
            <br>
 <center><b style="font-size: 12pt;">Validade em dias.<br>Por cada conta Criada!</b></center>
  <div class="textfield">
  
  <input required="required" type="number" class="form-control" id="dias_demo" name="dias_demo" placeholder="Digite a Validade em dias" value="<?php echo $row_srv_principal['dias'];?>" >
<br><br>
      
     <button type="submit" class="btn">Salvar</button>
    </form>
   </div>
  </div>
 </div>
  <script type="text/javascript" src="/SYSTEM/sort-table.js"></script>
   <script src="/CSS/index.js"></script>
    <script src="/CSS/inde.js"></script>