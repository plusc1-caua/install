<?php
include("MenuSub.php")
?>
      <main>
        <center>
        <h1>ADD Acessos Revenda</h1>
        </center>
        <form action="pages/usuario/addservidor_exe.php" method="POST" role="form">
        <div class="cards">
          
         <div class="textfield">
        <h3>Selecione um Servidor</h3>
       <select class="select" name="servidor" id="servidor">
         <option>Selecione Servidor</option>
                                            <?php


                                            $SQLAcesso= "select * from servidor where tipo='premium'";
                                            $SQLAcesso = $conn->prepare($SQLAcesso);
                                            $SQLAcesso->execute();


                                            if (($SQLAcesso->rowCount()) > 0) {
                                                while($row_srv = $SQLAcesso->fetch()) {



                                                    ?>

                                                    <option value="<?php echo $row_srv['id_servidor'];?>" > <?php echo $row_srv['nome'];?> - <?php echo $row_srv['ip_servidor'];?></option>

                                                <?php }
                                            }else{ ?>
                                                <option>Nenhum Servidor</option>
                                                <?php
                                            }

                                            ?>
               </select>
            </div>
            
         <div class="textfield">
        <h3>Selecione um Revenda</h3>
       <select class="select" name="revendedor" id="revendedor">
       <option>Selecione Revenda</option>
       <?php



                                            $SQL = "SELECT * FROM usuario where tipo='revenda' and subrevenda='nao' and id_mestre=0";
                                            $SQL = $conn->prepare($SQL);
                                            $SQL->execute();



                                            if (($SQL->rowCount()) > 0) {
                                                while($row = $SQL->fetch()) {

                                                    $SQLServidor = "select * from acesso_servidor  WHERE id_usuario = '".$row['id_usuario']."' ";
                                                    $SQLServidor = $conn->prepare($SQLServidor);
                                                    $SQLServidor->execute();
                                                    $acesso_server=$SQLServidor->rowCount();

                                                    ?>

                                                    <option value="<?php echo $row['id_usuario'];?>" ><?php echo $row['login'];?> </option>

                                                <?php }
                                            }else{ ?>
                                            <option>Nenhum Revenda</option>
                                                <?php
                                            }

                                            ?>
                                        </select>
            </div>
            
         <div class="textfield">
        <h3>Validade em Dias</h3>
       <input type="number" name="dias" id="dias" class="form-control" placeholder="Validade Painel" value="31" required>
            </div>
            
         <div class="textfield">
        <h3>Limite do Painel</h3>
       <input type="number" name="limite" id="limite" placeholder="Limite Painel" class="form-control" required>
            </div>
            
         <center>
       <button name="botaologin" class="btn-login" type="submit">Criar</button>
       <button name="botaologin" class="btn-login" type="reset">Limpar</button>
         </center>
          </div>
         </form>
       </main>
      <!----------------- END OF MAIN -------------------->
      <div class="right">
        <div class="top">
          <button id="menu-btn">
            <span class="material-icons-sharp"><ion-icon name="menu-sharp"></ion-icon></span>
          </button>
          <div class="theme-toggler">
            <span class="material-icons-sharp active">light_mode</span>
            <span class="material-icons-sharp">dark_mode</span>
          </div>
          <div class="profile">
            <div class="info">
              <p>Olá, <b><?php echo strtoupper($administrador['nome']);?></b></p>
              <small class="text-muted">Administrador</small>
            </div>
            <div class="profile-photo">
             <a href="/admin/MenuSub.php?page=admin/dados">
              <img src="/PNG/admin.png" /></a>
            </div>
          </div>
        </div>
    <script src="/CSS/index.js"></script>