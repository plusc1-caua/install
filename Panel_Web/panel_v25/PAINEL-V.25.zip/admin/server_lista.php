<?php
include("MenuSub.php")
?>
    <main>
     <center>
      <h1>Lista Servidor</h1>
        <div class="recent-orders">
         <div class="scroller">
          <table class="js-sort-table" id="customers">
                        <tr>
                            
                            <th>
                            SERVER
                            </th>
                               
                            <th>
                            REGIÃO
                            </th>
                                             
                            <th>
                            ENDEREÇO IP
                            </th>
                            
                            <th>
                            USUÁRIO
                            </th>
                            
                            <th>
                            CRIADO
                            </th>
                            
                            <th>
                            USADO
                            </th>
                            
                            <th>
                            EDITAR
                            </th>
                            
                        </tr>
                        <?php





                            $SQLServidor = "select * from servidor";
                            $SQLServidor = $conn->prepare($SQLServidor);
                            $SQLServidor->execute();

                            // output data of each row
                            if (($SQLServidor->rowCount()) > 0) {

                                while ($row = $SQLServidor->fetch()) {
                                    $acessos = 0;

                                    if ($row['tipo'] == 'premium') {
                                        $SQLAcessoSSH = "SELECT sum(acesso) AS quantidade  FROM usuario_ssh where id_servidor='" . $row['id_servidor'] . "' ";
                                        $SQLAcessoSSH = $conn->prepare($SQLAcessoSSH);
                                        $SQLAcessoSSH->execute();
                                        $SQLAcessoSSH = $SQLAcessoSSH->fetch();
                                        $acessos += $SQLAcessoSSH['quantidade'];

                                        $SQLUsuarioSSH = "select * from usuario_ssh WHERE id_servidor = '" . $row['id_servidor'] . "' ";
                                        $SQLUsuarioSSH = $conn->prepare($SQLUsuarioSSH);
                                        $SQLUsuarioSSH->execute();
                                    } else {
                                        $SQLUsuarioSSH = "select * from usuario_ssh_free WHERE servidor = '" . $row['id_servidor'] . "' ";
                                        $SQLUsuarioSSH = $conn->prepare($SQLUsuarioSSH);
                                        $SQLUsuarioSSH->execute();
                                    }

                                    $qtd_ssh = $SQLUsuarioSSH->rowCount();

                                    switch ($row['tipo']) {
                                        case 'premium':
                                            $tipo = 'Premium';
                                            break;
                                        case 'free':
                                            $tipo = 'Free';
                                            break;
                                        default:
                                            $tipo = 'erro';
                                            break;
                                    }

                                    $SQLopen = "select * from ovpn WHERE servidor_id = '" . $row['id_servidor'] . "' ";
                                    $SQLopen = $conn->prepare($SQLopen);
                                    $SQLopen->execute();
                                    if ($SQLopen->rowCount() > 0) {
                                        $openvpn = $SQLopen->fetch();
                                    }


                                    ?>
                                        <tr <?php echo $color; ?>>

                      <td>
                      <?php echo $row['nome']; ?>
                      </td>
                         
                      <td>
                      <div class="<?php echo $sts;?>">
                      <?php echo ucfirst($row['regiao']); ?>
                      </div>
                      </td>
                                              
                      <td>
                      <?php echo $row['ip_servidor']; ?>
                      </td>
                      
                      <td>
                      <?php echo $row['login_server']; ?>
                      </td>
                      
                      <td>
                      <?php echo $qtd_ssh; ?>
                      </td>
                      
                      <td>
                      <?php echo $acessos; ?>
                      </td>
                      
                    <td>
                     <a href="MenuSub.php?page=servidor/servidor&id_servidor=<?php echo $row['id_servidor']; ?>">
                     <button class="botao2">
                     <ion-icon name="brush"></ion-icon>
                     </button>
                     </a>
                     </td>
                         
                      </tr>


                            <?php }
                            }


                            ?>
                            
                     </table>
                   </div>
                 </div>
                 </main>
      <!----------------- END OF MAIN -------------------->
      <div class="right">
        <div class="top">
          <button id="menu-btn">
            <span class="material-icons-sharp"><ion-icon name="menu-sharp"></ion-icon></span>
          </button>
          <div class="theme-toggler">
            <span class="material-icons-sharp active">light_mode</span>
            <span class="material-icons-sharp">dark_mode</span>
          </div>
          <div class="profile">
            <div class="info">
              <p>Olá, <b><?php echo strtoupper($administrador['nome']);?></b></p>
              <small class="text-muted">Administrador</small>
            </div>
            <div class="profile-photo">
             <a href="/admin/MenuSub.php?page=admin/dados">
              <img src="/PNG/admin.png" /></a>
            </div>
          </div>
        </div>
        <script type="text/javascript" src="/SYSTEM/sort-table.js"></script>
        <script src="/CSS/index.js"></script>