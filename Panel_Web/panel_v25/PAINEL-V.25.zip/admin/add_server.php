<?php
include("MenuSub.php")
?>
<script>
    function ValidateIPaddress(inputText)
    {
        var ipformat = /^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
        if(inputText.value.match(ipformat))
        {
            document.form1.ip.focus();
            return true;
        }
        else
        {
            alert("Endereço IP Invalido!");
            document.form1.ip.focus();<br>return false;
        }
    }
</script>
      <main>
        <center>
        <h1>Adicionar Servidor</h1>
        </center>
        <form action="pages/servidor/adicionar_exe.php" method="POST" enctype="multipart/form-data" role="form">
        <div class="cards">
          
         <div class="textfield">
        <h3>Nome do Servidor</h3>
       <input type="text" id="nomesrv" name="nomesrv" class="form-control" minlength="3" placeholder="Ex: Brasil-1" required>
            </div>
            
         <div class="textfield">
        <h3>Endereço IP</h3>
       <input type="text" name="ip" id="ip" class="form-control" minlength="4" placeholder="Digite o IP" required>
            </div>
            
         <div class="textfield">
        <h3>Usuário Root</h3>
       <input type="text" name="login" id="login" value="root" class="form-control" required>
            </div>
            
         <div class="textfield">
        <h3>Senha Root</h3>
       <input type="password" min="4" max="32" class="form-control"  name="senha" data-minlength="4" id="senha" placeholder="Digite a Senha" required>
            </div>
            
         <div class="textfield">
        <h3>Região Global</h3>
       <select class="form-control custom-select" name="regiao" data-placeholder="Selecione a regiao" tabindex="1">
     <option value="1">Asia</option>
     <option value="2" selected>America</option>
     <option value="3">Europa</option>
     <option value="4">Australia</option>
        </select>
            </div>
            
         <div class="textfield">
        <h3>Localização</h3>
       <input type="text" name="localiza" id="localiza" placeholder="Ex: São Paulo" value="São Paulo" class="form-control" required>
            </div>
            
         <div class="textfield">
        <h3>Hostname</h3>
       <input type="text" name="siteserver" id="siteserver" value="www.painelssh.com.br" class="form-control" placeholder="Digite seu endereço do site ou IP" required>
            </div>
            
         <div class="textfield">
        <h3>Validade</h3>
        <input type="number" name="validade" id="validade" placeholder="Ex: 1000" value="1000" class="form-control" required>
            </div>
            
         <div class="textfield">
        <h3>Limite</h3>
       <input type="number" name="limite" id="limite" placeholder="Ex: 1000" value="1000" class="form-control" required>
            </div>
            
         <center>
       <button name="botaologin" class="btn-login2" type="submit">Adicionar</button>
       <button name="botaologin" class="btn-login" type="reset">Limpar</button>
         </center>
          </div>
         </form>
       </main>
      <!----------------- END OF MAIN -------------------->
      <div class="right">
        <div class="top">
          <button id="menu-btn">
            <span class="material-icons-sharp"><ion-icon name="menu-sharp"></ion-icon></span>
          </button>
          <div class="theme-toggler">
            <span class="material-icons-sharp active">light_mode</span>
            <span class="material-icons-sharp">dark_mode</span>
          </div>
          <div class="profile">
            <div class="info">
              <p>Olá, <b><?php echo strtoupper($administrador['nome']);?></b></p>
              <small class="text-muted">Administrador</small>
            </div>
            <div class="profile-photo">
             <a href="/admin/MenuSub.php?page=admin/dados">
              <img src="/PNG/admin.png" /></a>
            </div>
          </div>
        </div>
    <script src="/CSS/index.js"></script>