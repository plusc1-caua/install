       <div class="recent-orders">
          <h2>Usuários Online</h2>
           <table class="table table-hover mb-0 js-sort-table" id="MeuServidor" data-search="minhaPesquisa-lista">
                      <thead>
                      <tr>
                          <th>LOGIN</th>
                          <th>SERVER</th>
                          <th>CONEXAO</th>
                      </tr>
                      </thead>
                      <?php
                      $SQLSub = "SELECT * FROM usuario_ssh";
                      $SQLSub = $conn->prepare($SQLSub);
                      $SQLSub->execute();

                      if(($SQLSub->rowCount()) > 0){
                          while($rowSub = $SQLSub->fetch()) {

                              $SQLSSH = "SELECT * FROM servidor where tipo='premium' and id_servidor='".$rowSub['id_servidor']."' ORDER BY id_servidor";
                              $SQLSSH = $conn->prepare($SQLSSH);
                              $SQLSSH->execute();
                              $row = $SQLSSH->fetch();

                              //Calcula os dias restante
                              $dias_acesso = 0 ;

                              $data_atual = date("Y-m-d ");
                              $data_validade = $rowSub['data_validade'];
                              if($data_validade > $data_atual){
                                  $data1 = new DateTime( $data_validade );
                                  $data2 = new DateTime( $data_atual );
                                  $dias_acesso = 0;
                                  $diferenca = $data1->diff( $data2 );
                                  $ano = $diferenca->y * 364 ;
                                  $mes = $diferenca->m * 30;
                                  $dia = $diferenca->d;
                                  $dias_acesso = $ano + $mes + $dia;

                              }

                              $SQLSubowner = "SELECT * FROM usuario where id_usuario='".$rowSub['id_usuario']."'";
                              $SQLSubowner = $conn->prepare($SQLSubowner);
                              $SQLSubowner->execute();
                              $own=$SQLSubowner->fetch();

                              $status="";
                              if($rowSub['status']== 1){
                                  $status="Ativo";
                                  $class = "'";
                              }else{
                                  $status="Inativo";
                              }

                              if($rowSub['online'] != 0){

                                  ?>
                                  <tr>

                                      <td class="warning"><?php echo $rowSub['login'];?></td>
                                      
                                      <td><?php echo $row['nome'];?></td>
                                      <td class="primary">0<?php echo $rowSub['online'];?> de 0<?php echo $rowSub['acesso'];?></td>
                                      
                                      
                                  </tr>
                                  <?php
                              }
                          }
                      }

                      ?>
          </table>
          </div>
      </main>
        <?php


        if(isset($_GET["page"])){
            $page = $_GET["page"];
            if($page and file_exists("".$page.".php")) {
                include("".$page.".php");
            } else {
                include("home4.php");
            }
        }else{
            include("home4.php");
        }

        ?>