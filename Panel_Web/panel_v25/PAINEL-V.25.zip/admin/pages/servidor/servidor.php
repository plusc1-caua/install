<?php


if (basename($_SERVER["REQUEST_URI"]) === basename(__FILE__)) {
    exit('<h1>ERROR 404</h1>Entre em contato conosco e envie detalhes.');
}

if (isset($_GET["id_servidor"])) {
    $SQLServidor = "select * from servidor WHERE id_servidor = '" . $_GET['id_servidor'] . "' ";
    $SQLServidor = $conn->prepare($SQLServidor);
    $SQLServidor->execute();
    $servidor = $SQLServidor->fetch();
    if (($SQLServidor->rowCount()) == 0) {
        echo '<script type="text/javascript">';
        echo     'alert("Nao encontrado!");';
        echo    'window.location="/server_lista.php";';
        echo '</script>';
        exit;
    }
} else {
    echo '<script type="text/javascript">';
    echo     'alert("Preencha todos os campos!");';
    echo    'window.location="/server_lista.php";';
    echo '</script>';
    exit;
}


//Realiza a comunicacao com o servidor
$ip_servidor = $servidor['ip_servidor'];
$loginSSH = $servidor['login_server'];
$senhaSSH =  $servidor['senha'];
$ssh = new SSH2($ip_servidor);



//Verifica se o servidor esta online
$servidor_online = $ssh->online($ip_servidor);
if ($servidor_online) {
    $servidor_autenticado = $ssh->auth($loginSSH, $senhaSSH);
    if ($servidor_autenticado) {
        $status = "<div class='onlinee'>

                <h3><center>Autenticado</center></h3>

              </div>";
        //Verifica memoria
        $ssh->exec("free -m");
        $mensagem = (string) $ssh->output();
        $words = preg_split(
            "/[\s,]*\\\"([^\\\"]+)\\\"[\s,]*|" . "[\s,]*'([^']+)'[\s,]*|" . "[\s,]+/",
            $mensagem,
            0,
            PREG_SPLIT_NO_EMPTY | PREG_SPLIT_DELIM_CAPTURE
        );
        //Memoria total $words[7]
        //Memoria usada $words[8]
        //Memoria livre $words[9]

        //Quantidade de CPU fisico
        $ssh->exec("cat /proc/cpuinfo | grep 'physical id' | sort | uniq | wc -l ");
        $mensagem_f = (string) $ssh->output();
        $cpu_fisico = $mensagem_f;

        //Quantidade de CPU Virtual
        $ssh->exec("cat /proc/cpuinfo | egrep 'core id|physical id' | tr -d '\n' | sed s/physical/\\nphysical/g | grep -v ^$ | sort | uniq | wc -l");
        $mensagem_v = (string) $ssh->output();
        $cpu_virtual = $mensagem_v;

        //Nome do Processador
        $ssh->exec("cat /proc/cpuinfo | egrep ' model name|model name'");
        $mensagem_p = (string) $ssh->output();
        $partes = explode(":", $mensagem_p);
        $nome_processador = $partes[1];

        //UPTIME
        $ssh->exec("uptime -p");
        $mensagem_u = (string) $ssh->output();
        $uptime = $mensagem_u;
####################################################################################
			//entrada
			$ssh->exec("ifconfig eth0 | grep 'RX bytes' | awk '{print $3 $4}'");
			$mensagem_u = (string) $ssh->output();
			$download1 = $mensagem_u;

			//entrada
			$ssh->exec("ifconfig lo | grep 'RX bytes' | awk '{print $3 $4}'");
			$mensagem_u = (string) $ssh->output();
			$download2 = $mensagem_u;
			
			//entrada
			$ssh->exec("ifconfig venet0 | grep 'RX bytes' | awk '{print $3 $4}'");
			$mensagem_u = (string) $ssh->output();
			$download3 = $mensagem_u;
####################################################################################			
			//saida
			$ssh->exec("ifconfig eth0 | grep 'RX bytes' | awk '{print $7 $8}'");
			$mensagem_u = (string) $ssh->output();
			$upload1 = $mensagem_u;
			
			//saida
			$ssh->exec("ifconfig lo | grep 'RX bytes' | awk '{print $7 $8}'");
			$mensagem_u = (string) $ssh->output();
			$upload2 = $mensagem_u;
			
			//saida
			$ssh->exec("ifconfig venet0 | grep 'RX bytes' | awk '{print $7 $8}'");
			$mensagem_u = (string) $ssh->output();
			$upload3 = $mensagem_u;
####################################################################################
        if ($servidor['tipo'] <> 'free') {
            //Usuarios SSH online neste servidor
            $SQLContasSSH = "SELECT sum(online) AS soma  FROM usuario_ssh where id_servidor = '" . $_GET['id_servidor'] . "'   ";
            $SQLContasSSH = $conn->prepare($SQLContasSSH);
            $SQLContasSSH->execute();
            $SQLContasSSH = $SQLContasSSH->fetch();
            $usuarios_online = $SQLContasSSH['soma'];
        }
    } else {
        $status = "<div class='suspenso'>

                <h3><center>Não Autenticado </center></h3>

              </div>";
    }
} else {
    $status = "<div class='offline'>

                <h3><center>OFFLINE </center></h3>

              </div>";
}

?>
<main>
 <center><h1>Informações do servidor</h1></center>
 <div class="cards">
<div class="sales">
  <div class="linha">
  
  <?php echo $status; ?>
<br>
 <center><b><?php echo $nome_processador; ?></b></center>
<br>
  <li class="list-group-item">
  <div class="linha">
  <b>CPU física:</b> <?php echo $cpu_fisico; ?>
  </li>
  <li class="list-group-item">
  <div class="linha">
  <b>CPU Virtual:</b> <?php echo $cpu_virtual; ?>
  </li>
  <li class="list-group-item">
  <div class="linha">
  <b>Memoria total:</b> <?php echo $words[7]; ?> Mb
  </li>
  <li class="list-group-item">
  <div class="linha">
  <b>Memoria usada:</b> <?php echo $words[8]; ?> Mb
  </li>
  <li class="list-group-item">
  <div class="linha">
  <b>Memoria livre:</b> <?php echo $words[9]; ?> Mb
  </li>
  <li class="list-group-item">
  <div class="linha">
  <b>Memoria cache:</b> <?php echo $words[11]; ?> Mb
  </li>
  <li class="list-group-item">
  <div class="linha">
  <b>Ligado:</b> <?php echo $uptime; ?>
  </li>
  
 <center><h3>Ações</h3></center>
  <form>
                                    <?php if ($servidor_autenticado) { ?>
                                        <script type="text/javascript">
                                            function updatescripts() {
                                                decisao = confirm("Realmente quer atualizar? , os usuarios serão resetados!");
                                                if (decisao) {
                                                    window.location.href = '../admin/pages/servidor/servidor_exe.php?id_servidor=<?php echo $servidor['id_servidor']; ?>&op=updateScript'
                                                } else {

                                                }
                                            }
                                        </script>
  <center>
   <br>
   <a href="../admin/pages/servidor/servidor_exe.php?id_servidor=<?php echo $servidor['id_servidor']; ?>&op=reiniciar" class="btn2">Reiniciar Servidor</a>
    <br><br>   <br>
    
   <a href="../admin/pages/servidor/servidor_exe.php?id_servidor=<?php echo $servidor['id_servidor']; ?>&op=desligar" class="btn1">Desligar Servidor</a>
   <br><br>   <br>
   
   <a onclick="updatescripts()" class="btn">Sincronizar Servidor</a>
</center>
<br>
 <?php } ?>
  </div>
</div>
 </form>
</div>
 <br>
  <center><h1>Editar Servidor</h1></center>
   <div class="cards">
    <div class="tab">
<center>
  <button class="tablinks" onclick="openCity(event, 'info')">Informações</button>
  <button class="tablinks" onclick="openCity(event, 'conta')">Conta SSH</button>
</center>
 </div>
</div>
  <div id="conta" class="tabcontent">
     <div class="recent-orders">
        <div class="scroller">
          <table class="js-sort-table" id="customers">
                                        <tr>
                                            <th>LOGIN</th>
                                            <th>VALIDO</th>
                                            <th>ONLINE</th>
                                            <th>LIMITE</th>
											<th>EDITAR</th>
                                        </tr>
                                        <?php
                                        if ($servidor['tipo'] == 'free') {
                                            $SQLUsuarioSSH = "select * from usuario_ssh_free where servidor='" . $servidor['id_servidor'] . "'  ";
                                        } else {
                                            $SQLUsuarioSSH = "select * from usuario_ssh where id_servidor='" . $servidor['id_servidor'] . "'  ";
                                        }
                                        $SQLUsuarioSSH = $conn->prepare($SQLUsuarioSSH);
                                        $SQLUsuarioSSH->execute();

                                        if (($SQLUsuarioSSH->rowCount()) > 0) {
                                            while ($row2 = $SQLUsuarioSSH->fetch()) {
                                                if ($servidor['tipo'] <> 'free') {
                                                    $SQLTotalUser = "select * from usuario_ssh WHERE id_servidor='" . $servidor['id_servidor'] . "' ";
                                                    $SQLTotalUser = $conn->prepare($SQLTotalUser);
                                                    $SQLTotalUser->execute();
                                                    $total_user = $SQLTotalUser->rowCount();

                                                    $SQLAcessoSSH = "SELECT sum(acesso) AS quantidade  FROM usuario_ssh where id_servidor = '" . $row2['id_servidor'] . "'  and id_usuario='" . $_GET['id_usuario'] . "' ";
                                                    $SQLAcessoSSH = $conn->prepare($SQLAcessoSSH);
                                                    $SQLAcessoSSH->execute();
                                                    $SQLAcessoSSH = $SQLAcessoSSH->fetch();
                                                    $acessos += $SQLAcessoSSH['quantidade'];
                                                }
                                                $data_atual = date("Y-m-d ");
                                                $data_validade = $row2['data_validade'];
                                                if ($data_validade > $data_atual) {
                                                    $data1 = new DateTime($data_validade);
                                                    $data2 = new DateTime($data_atual);
                                                    $dias_acesso = 0;
                                                    $diferenca = $data1->diff($data2);
                                                    $ano = $diferenca->y * 364;
                                                    $mes = $diferenca->m * 30;
                                                    $dia = $diferenca->d;
                                                    $dias_acesso = $ano + $mes + $dia;
                                                }
                                                ?>
                                                <tr>
                      <td><?php echo $row2['login']; ?></td>
                      <td><?php echo $dias_acesso . "  dias   "; ?>
                      </td>
                      <td><?php if ($servidor['tipo'] == 'premium') {
                                     echo $row2['online'];
                                            } else {
                                     echo "<small>Server Free</small>";
                                                    } ?></td>
                      <td><?php echo $row2['acesso'];?></td>
		              <td> 
		              <a href="MenuSub.php?page=ssh/editar&id_ssh=<?php echo $row2['id_usuario_ssh'];?>">
                     <button class="botao2">
                     <ion-icon name="brush"></ion-icon>
                     </button>
                     </td>			
                                                </tr>
												
                                        <?php
                                            }
                                        }
                                        ?>
                         </table>
                   </div>
                 </div>
               </div>
</main>
      <div class="right">
        <div class="top">
          <button id="menu-btn">
            <span class="material-icons-sharp"><ion-icon name="menu-sharp"></ion-icon></span>
          </button>
          <div class="theme-toggler">
            <span class="material-icons-sharp active">light_mode</span>
            <span class="material-icons-sharp">dark_mode</span>
          </div>
          <div class="profile">
            <div class="info">
              <p>Olá, <b><?php echo strtoupper($administrador['nome']);?></b></p>
              <small class="text-muted">Administrador</small>
            </div>
            <div class="profile-photo">
             <a href="/admin/MenuSub.php?page=admin/dados">
              <img src="/PNG/admin.png" /></a>
            </div>
          </div>
        </div>
<div class="sales-analytics">
 <div id="info" class="tabcontent">
  <div class="item online">
  
  <form role="form" action="pages/servidor/editar_exe.php" method="post" enctype="multipart/form-data">
 <center><h2>Dados do Revenda</h2></center>
 <input type="hidden" class="form-control" id="id_servidor" name="id_servidor" value="<?php echo $servidor['id_servidor']; ?>">
 
 <b style="font-size: 12pt;">Nome</b>
  <input required="required" type="text" class="caa" id="nomesrv" name="nomesrv" value="<?php echo $servidor['nome']; ?>">
<br><br>

 <b style="font-size: 12pt;">Endereço IP</b>
  <input required="required" type="text" class="caa" id="ip" name="ip" value="<?php echo $servidor['ip_servidor']; ?>">
<br><br>

 <b style="font-size: 12pt;">Usuário Root</b>
  <input required="required" type="text" class="caa" id="login" name="login" value="<?php echo $servidor['login_server']; ?>">
<br><br>

 <b style="font-size: 12pt;">Senha Root</b>
  <input required="required" type="password" class="caa" id="login" name="senha" value="<?php echo $servidor['senha']; ?>">
<br><br>

 <b style="font-size: 12pt;">Hostname</b>
  <input required="required" type="text" class="caa" id="siteserver" name="siteserver" value="<?php echo $servidor['site_servidor']; ?>">
<br><br>
      
 <b style="font-size: 12pt;">Localização</b>
  <input required="required" type="text" class="caa" id="localiza" name="localiza" value="<?php echo $servidor['localizacao']; ?>">
<br><br>                                       

 <b style="font-size: 12pt;">Validade</b>
  <input required="required" type="text" maxlength="2" class="caa" id="validade" name="validade" value="<?php echo $servidor['validade']; ?>">
<br><br>
      
 <b style="font-size: 12pt;">Limite</b>
  <input required="required" type="text" maxlength="3" class="caa" id="limite" name="limite" value="<?php echo $servidor['limite']; ?>">
<br><br>                                       

  <button type="submit" class="btn">Alterar Dados</button>
  <button type="reset" class="bt">Resetar</button>
   </div>
 
  <div class="item online">
     <center><h2>Outras<br>Ações</h2></center>
  <div class="item online">
     <center>
        <a href="../admin/pages/servidor/servidor_exe.php?id_servidor=<?php echo $servidor['id_servidor']; ?>&op=deletarGeral" class="bn3">Deletar Tudo</a>
       <br></br><br>
        <a href="../admin/pages/servidor/servidor_exe.php?id_servidor=<?php echo $servidor['id_servidor']; ?>&op=deletarContas" class="bn3">Deletar Contas</a>
      <br><br><br>
      <?php if ($servidor['manutencao'] == 'nao') { ?>
        <a href="../admin/pages/servidor/servidor_exe.php?id_servidor=<?php echo $servidor['id_servidor']; ?>&op=manutencao" class="bn2">Bloquear</a>
        <br><br>
        <p>Desativa criação user!</p>
        
        <?php } else { ?>
        <a href="../admin/pages/servidor/servidor_exe.php?id_servidor=<?php echo $servidor['id_servidor']; ?>&op=manutencao" class="bn1">Desbloquear</a>
        <br><br>
        <p>Ativar criação user!</p>
        </div>
       </center>
     </div>
   </form>  
  <?php } ?>
 </div>
</div>

  <script type="text/javascript" src="/SYSTEM/sort-table.js"></script>
   <script src="/CSS/index.js"></script>
   <script src="/CSS/inde.js"></script>