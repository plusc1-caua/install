<?php

if (basename($_SERVER["REQUEST_URI"]) === basename(__FILE__))
{
	exit('<h1>ERROR 404</h1>Entre em contato conosco e envie detalhes.');
}

?>
<?php
$dias_acesso=0;

if(isset($_GET["id_ssh"])){

	$diretorio="../../admin/MenuSub.php?page=ssh/editar&id_ssh=".$_GET['id_ssh'];


	$SQLUsuarioSSH = "select * from usuario_ssh WHERE id_usuario_ssh = '".$_GET['id_ssh']."' ";
  $SQLUsuarioSSH = $conn->prepare($SQLUsuarioSSH);
  $SQLUsuarioSSH->execute();


  $usuario_ssh = $SQLUsuarioSSH->fetch();

  if(($SQLUsuarioSSH->rowCount()) > 0){

    $SQLServidor = "select * from servidor WHERE id_servidor = '".$usuario_ssh['id_servidor']."'  ";
    $SQLServidor = $conn->prepare($SQLServidor);
    $SQLServidor->execute();
    $ssh_srv = $SQLServidor->fetch();

        //Calcula os dias restante
    $data_atual = date("Y-m-d ");
    $data_validade = $usuario_ssh['data_validade'];
    if($data_validade > $data_atual){
     $data1 = new DateTime( $data_validade );
     $data2 = new DateTime( $data_atual );
     $dias_acesso = 0;
     $diferenca = $data1->diff( $data2 );
     $ano = $diferenca->y * 364 ;
     $mes = $diferenca->m * 30;
     $dia = $diferenca->d;
     $dias_acesso = $ano + $mes + $dia;

   }else{
    $dias_acesso = 0;
  }

  $explo=explode("-",$data_validade);
  $ano=$explo[0];
  $mes=$explo[1];
  $dia=$explo[2];
  
  $SQLUsuario = "select * from usuario WHERE id_usuario = '".$usuario_ssh['id_usuario']."'  ";
  $SQLUsuario = $conn->prepare($SQLUsuario);
  $SQLUsuario->execute();


  $usuario_sistema = $SQLUsuario->fetch();

  $owner;

  if(!(($SQLUsuario->rowCount())  > 0)){

    echo '<script type="text/javascript">';
    echo 	'alert("Nao encontrado!");';
    echo	'window.location="/user_lista.php";';
    echo '</script>';
    exit;
  }

}else{
  echo '<script type="text/javascript">';
  echo 	'alert("Nao encontrado!");';
  echo	'window.location="/user_lista.php";';
  echo '</script>';
  exit;
}


}else{
 echo '<script type="text/javascript">';
 echo 	'alert("Preencha todos os campos!");';
 echo	'window.location="/user_lista.php";';
 echo '</script>';
 exit;

}


if($usuario_ssh['online'] >= 1){
  $status= "<div class='onlinee'>

  <h2><center>ONLINE</center></h2>
  <center>".$usuario_ssh['online']." conexão de ".$usuario_ssh['acesso']."</center>

  </div>";

}else{
 $status= "<div style='color: #F8F8FF;' class='offline'>

 <h2><center>OFFLINE</center></h2>

 </div>";
}

if($usuario_ssh['status'] >= 2){
  $status= "<div class='suspenso'>

  <h2><center>SUSPENSO</center></h2>

  </div>";
}

?>
<main>
 <center><h1>Informações da Conta</h1></center>
 <div class="cards">
  <div class="linha">
  
  <?php echo $status; ?>
<br>
  <li class="list-group-item">
  <div class="linha">
  <b>VENCIMENTO:</b> <?php echo $dia;?>/<?php echo $mes;?>/<?php echo $ano;?>
  </li>
  <li class="list-group-item">
  <div class="linha">
  <b>SERVIDOR:</b> <?php echo $ssh_srv['nome'];?>
  </li>
  <li class="list-group-item">
  <div class="linha">
  <b>USUÁRIO:</b> <?php echo $usuario_ssh['login'];?>
  </li>
  <li class="list-group-item">
  <div class="linha">
  <b>SENHA:</b> <?php echo $usuario_ssh['senha'];?>
  </li>
  <li class="list-group-item">
  <div class="linha">
  <b>FALTA:</b> <?php echo $dias_acesso." dias"; ?>
  </li>
  <li class="list-group-item">
  <div class="linha">
  <b>LIMITE:</b> <?php echo $usuario_ssh['acesso']; ?>
  </li>
  <li class="list-group-item">
  <div class="linha">
  <b>DONO:</b> <a href="MenuSub.php?page=usuario/perfil&id_usuario=<?php echo $usuario_sistema['id_usuario'];?>"><?php echo $usuario_sistema['nome'];?></a>
  </li>
  
    <form role="form2" action="../pages/system/funcoes.conta.ssh.php" method="post" class="form-horizontal">
       
    <input type="hidden"  id="diretorio" name="diretorio" value="../../admin/user_lista.php"  >
    <input type="hidden"  id="id_usuario_ssh" name="id_usuario_ssh" value="<?php echo $usuario_ssh['id_usuario_ssh']; ?>"  >
    <input type="hidden"  id="owner" name="owner" value="<?php echo $accessKEY; ?>"  >
    
<center>
 <button type="submit" data-toggle="tooltip" title="Remove do Servidor" class="btn1" id="op" name="op" value="deletar" >Deletar</button>

 <?php if($usuario_ssh['status']==2){?>
 <button type="submit" data-toggle="tooltip" title="Reativa a Conta SSH" class="btn3" id="op" name="op" value="ususpender" >Reativar</button>
 <br> 
 <?php }else{ ?> 
 <button type="submit" data-toggle="tooltip" title="Suspende Temporariamente" class="btn2" id="op" name="op" value="suspender" >Bloquear</button>
 </center>

   <?php } ?>
  </div>
  </div>
 </form>
</section>
</main>
      <!----------------- END OF MAIN -------------------->
      <div class="right">
        <div class="top">
          <button id="menu-btn">
            <span class="material-icons-sharp"><ion-icon name="menu-sharp"></ion-icon></span>
          </button>
          <div class="theme-toggler">
            <span class="material-icons-sharp active">light_mode</span>
            <span class="material-icons-sharp">dark_mode</span>
          </div>
          <div class="profile">
            <div class="info">
              <p>Olá, <b><?php echo strtoupper($administrador['nome']);?></b></p>
              <small class="text-muted">Administrador</small>
            </div>
            <div class="profile-photo">
             <a href="/admin/MenuSub.php?page=admin/dados">
              <img src="/PNG/admin.png" /></a>
            </div>
          </div>
        </div>        
          <center><h2>Editar Dados da Conta</h2></center>
        <div class="sales-analytics">
         <div class="item online">
          <div class="tab">
<center>
  <button class="tablinks" onclick="openCity(event, 'Migrar')">Migrar</button>
  <button class="tablinks" onclick="openCity(event, 'Senha')">Senha</button>
  <button class="tablinks" onclick="openCity(event, 'Validade')">Validade</button>
  <button class="tablinks" onclick="openCity(event, 'Conexao')">Conexão</button>
</center>
 </div>
</div>

<div id="dono" class="tabcontent">
 <div class="item online">
<center>
<h2>Alterar dono Conta SSH</h2>
 <form role="owner" action="../pages/system/funcoes.conta.ssh.php" method="post" class="form-horizontal">
 
       <select class="ca" name="n_owner" id="n_owner">
             <option selected="selected" value="<?php echo $usuario_sistema['id_usuario']; ?>"><?php echo $usuario_sistema['login']; ?></option>
             <?php
             $owner = $usuario_sistema['id_usuario'];
             $SQLUsuario = "SELECT * FROM usuario ";
             $SQLUsuario = $conn->prepare($SQLUsuario);
             $SQLUsuario->execute();
             if (($SQLUsuario->rowCount()) > 0) {
                            							// output data of each row
              while($row = $SQLUsuario->fetch()) {
               if($row['id_usuario'] != $usuario_sistema['id_usuario']){
                ?>
                <option value="<?php echo $row['id_usuario'];?>" ><?php echo $row['login'];?></option>
              <?php }
            }
          }
          ?>
        </select>
       <input type="hidden"  id="op" name="op" value="owner"  >
       <input type="hidden"  id="diretorio" name="diretorio" value="<?php echo $diretorio; ?>"  >
       <input type="hidden"  id="id_usuario_ssh" name="id_usuario_ssh" value="<?php echo $usuario_ssh['id_usuario_ssh']; ?>">
       <input type="hidden"  id="owner" name="owner" value="<?php echo $accessKEY; ?>">

       <button type="submit" class="btn">Alterar Dono da Conta</button>
       </center>
     </form>
   </div>
 </div>


<div id="Migrar" class="tabcontent">
 <div class="item online">
<center>
<h2>Migrar Conta SSH</h2>
 
    <form role="migrar" action="../pages/system/funcoes.conta.ssh.php" method="post" class="form-horizontal">

      <p style="font-weight: bold;">Servidor Atual</p>
      <?php
      $SQLServidor = "select * from servidor WHERE id_servidor = '".$ssh_srv['id_servidor']."' ";
      $SQLServidor = $conn->prepare($SQLServidor);
      $SQLServidor->execute();
      $servidor = $SQLServidor->fetch();


      $SQLContasSSH = "SELECT sum(acesso) AS quantidade  FROM usuario_ssh where id_servidor = '".$ssh_srv['id_servidor']."'  ";
      $SQLContasSSH = $conn->prepare($SQLContasSSH);
      $SQLContasSSH->execute();
      $SQLContasSSH = $SQLContasSSH->fetch();
      $contas_ssh_criadas += $SQLContasSSH['quantidade'];
      ?>
      <input disabled required="required" type="text" class="ca"  value=" <?php echo $ssh_srv['nome'];?>" >

    <p style="font-weight: bold;">Selecione um servidor destino</p>
      <select class="ca"  name="id_new_servidor" id="id_new_servidor">

        <?php



        $SQLAcesso= "select * from servidor where id_servidor != '".$ssh_srv['id_servidor']."' ";
        $SQLAcesso = $conn->prepare($SQLAcesso);
        $SQLAcesso->execute();


        if (($SQLAcesso->rowCount()) > 0) {
    // output data of each row
          while($row_srv = $SQLAcesso->fetch()) {
            $contas_ssh_criadas = 0;

            $SQLServidor = "select * from servidor WHERE id_servidor = '".$row_srv['id_servidor']."' ";
            $SQLServidor = $conn->prepare($SQLServidor);
            $SQLServidor->execute();
            $servidor = $SQLServidor->fetch();


            $SQLContasSSH = "SELECT sum(acesso) AS quantidade  FROM usuario_ssh where id_servidor = '".$row_srv['id_servidor']."'  ";
            $SQLContasSSH = $conn->prepare($SQLContasSSH);
            $SQLContasSSH->execute();
            $SQLContasSSH = $SQLContasSSH->fetch();
            $contas_ssh_criadas += $SQLContasSSH['quantidade'];








            ?>

            <option value="<?php echo $row_srv['id_servidor'];?>" > <?php echo $servidor['nome'];?> </option>

          <?php }
        }

        ?>
      </select>

      <input type="hidden"  id="op" name="op" value="migrar"  >
      <input type="hidden"  id="diretorio" name="diretorio" value="<?php echo $diretorio; ?>"  >
      <input type="hidden"  id="id_ssh" name="id_ssh" value="<?php echo $usuario_ssh['id_usuario_ssh']; ?>"  >
      <input type="hidden"  id="owner" name="owner" value="<?php echo $accessKEY; ?>"  >

     <button type="submit" class="btn">Mudar de Servidor</button> 
  </center>
 </form>
</div>
</div>

<div id="Senha" class="tabcontent">
 <div class="item online">
<center>
 <h2>Alterar Senha</h2>

    <form role="senha" id="senha" name="senha" action="../pages/system/funcoes.conta.ssh.php" method="post" class="form-horizontal">
   
    <input required="required" type="text" class="ca" id="senha_ssh" name="senha_ssh" placeholder="Digite a nova senha">

        <input type="hidden"  id="op" name="op" value="senha"  >
        <input type="hidden"  id="id_ssh" name="id_ssh" value="<?php echo $_GET["id_ssh"]; ?>"  >
        <input type="hidden"  id="diretorio" name="diretorio" value="<?php echo $diretorio; ?>"  >
        <input type="hidden"  id="id_servidor" name="id_servidor" value="<?php echo $ssh_srv['id_servidor']; ?>"  >
        <input type="hidden"  id="id_usuario_ssh" name="id_usuario_ssh" value="<?php echo $usuario_ssh['id_usuario_ssh']; ?>"  >
        <input type="hidden"  id="owner" name="owner" value="<?php echo $accessKEY; ?>"  >
    
    <button type="submit" class="btn">Alterar Senha</button>
  </center>
 </form>
</div>
</div>

<div id="Validade" class="tabcontent">
 <div class="item online">
<center>
 <h2>Dias de acessos</h2>
 
   <form role="form2" action="../pages/system/funcoes.conta.ssh.php" method="post" class="form-horizontal">

    <input required="required" type="number" class="ca" id="dias" name="dias" placeholder="Quantidade dias de acesso" >
          <input type="hidden"  id="op" name="op" value="dias"  >
          <input type="hidden"  id="id_usuarioSSH" name="id_usuarioSSH" value="<?php echo $_GET["id_ssh"]; ?>"  >
          <input type="hidden"  id="diretorio" name="diretorio" value="<?php echo $diretorio; ?>"  >

          <input type="hidden"  id="owner" name="owner" value="<?php echo $accessKEY; ?>"  >
          
    <button type="submit" class="btn">Alterar dias de acesso</button>
    </center>
  </form>
 </div>
</div>
 
<div id="Conexao" class="tabcontent">
 <div class="item online">
<center>
 <h2>Acesso simultâneo</h2>

      <form role="form2" action="../pages/system/funcoes.conta.ssh.php" method="post" class="form-horizontal">
      
      <input required="required" type="number" class="ca" id="acesso" name="acesso" placeholder="Quantidade de acesso" >
      
            <input type="hidden"  id="op" name="op" value="acesso"  >
            <input type="hidden"  id="diretorio" name="diretorio" value="<?php echo $diretorio; ?>"  >
            <input type="hidden"  id="id_usuario_ssh" name="id_usuario_ssh" value="<?php echo $usuario_ssh['id_usuario_ssh']; ?>"  >
            <input type="hidden"  id="sistema" name="sistema" value="<?php echo $owner; ?>"  >
            <input type="hidden"  id="owner" name="owner" value="<?php echo $accessKEY; ?>"  >
            
     <button type="submit" class="btn">Alterar conexão simutanea</button>
        </center>
      </form>
    </div>
  </div>
</div>
<br><br><br>

  <script type="text/javascript" src="/SYSTEM/sort-table.js"></script>
   <script src="/CSS/index.js"></script>
    <script src="/CSS/inde.js"></script>