<?php

$procnoticias= "select * FROM noticias where status='ativo'";
$procnoticias = $conn->prepare($procnoticias);
$procnoticias->execute();


        // Clientes
        $SQLbuscaclientes= "select * from usuario where tipo='vpn'";
        $SQLbuscaclientes = $conn->prepare($SQLbuscaclientes);
        $SQLbuscaclientes->execute();
        $totalclientes = $SQLbuscaclientes->rowCount();
        // Revendedores
        $SQLbuscarevendedores= "select * from  usuario where tipo='revenda'";
        $SQLbuscarevendedores = $conn->prepare($SQLbuscarevendedores);
        $SQLbuscarevendedores->execute();
        $totalrevendedores = $SQLbuscarevendedores->rowCount();
        // Servidores
        $SQLbuscaservidores= "select * from  servidor";
        $SQLbuscaservidores= $conn->prepare($SQLbuscaservidores);
        $SQLbuscaservidores->execute();
        $totalservidores = $SQLbuscaservidores->rowCount();
?>
<main>
 <center><h1>Informações do Painel</h1></center>
<div class="cards">
 <div class="sales">
  <div class="linha">
 <center>  
 <img class="profile-photo" style="width: 70px; height: 70px;" src="../../PNG/admin.png"> 
 <h2><?php echo strtoupper($administrador['nome']);?></h2>
  <p>Tipo: Admin</p>
   </div>
    <center> 
     <br>
      </div>
       </div>
        <br><br>
        
 <center><h1>Editar Perfil do Painel</h1></center> 
<div class="cards">
 <div class="sales">     
    <form action="pages/admin/alterar.php" method="POST" role="form">
    <center>
 <b style="font-size: 12pt;">Nome</b>
  <input type="text" name="nome" id="nome" class="caa" minlength="3"  value="<?php echo $administrador['nome'];?>" required>
<br><br>

 <b style="font-size: 12pt;">E-Mail</b>
  <input type="text" name="email" id="email" minlength="3" class="caa" value="<?php echo $administrador['email'];?>" required>
<br><br>

 <b style="font-size: 12pt;">Site Painel</b>
  <input type="text" name="site" id="site" minlength="3" value="<?php echo $administrador['site'];?>" class="caa" required>
<br><br>

 <b style="font-size: 12pt;">Celular</b>
  <input type="text" class="caa" minlength="11" id="celular" name="celular" value="<?php echo $usuario['celular'];?>" placeholder="Celular" required="required">
<br><br>

 <b style="font-size: 12pt;">Senha Antiga</b>
  <input type="password" name="senhaantiga" id="senhaantiga" minlength="3" placeholder="Digite a Senha Antiga" class="caa">
<br><br>
      
 <b style="font-size: 12pt;">Senha Nova</b>
  <input type="password" name="novasenha" id="novasenha" minlength="3" placeholder="Digite a Nova Senha" class="caa">
<br><br>
      
     <button type="submit" class="btn">Salvar Dados</button>
     <button type="reset" class="bt">Resetar</button>
    </form>
   <center>   
  </div>
 </div>
</main>
      <!----------------- END OF MAIN -------------------->
      <div class="right">
        <div class="top">
          <button id="menu-btn">
            <span class="material-icons-sharp"><ion-icon name="menu-sharp"></ion-icon></span>
          </button>
          <div class="theme-toggler">
            <span class="material-icons-sharp active">light_mode</span>
            <span class="material-icons-sharp">dark_mode</span>
          </div>
          <div class="profile">
            <div class="info">
              <p>Olá, <b><?php echo strtoupper($administrador['nome']);?></b></p>
              <small class="text-muted">Administrador</small>
            </div>
            <div class="profile-photo">
             <a href="/admin/MenuSub.php?page=admin/dados">
              <img src="/PNG/admin.png" /></a>
            </div>
          </div>
        </div>

  <div class="sales-analytics">
   <div class="item online"> 
<?php
$procnoticias = "select * FROM noticias where status='ativo'";
$procnoticias = $conn->prepare($procnoticias);
$procnoticias->execute();
?>
<section id="input-style">
 <form role="form" action="pages/apis/addnoti.php" method="post" onsubmit="return confirm('Tem certeza que deseja fazer isso');" enctype="multipart/form-data">

 <center>
  <h2>Noticiar na Tela Inicial</h2><br>
   <p>Notificar seus clientes!</p>
    <br>
     <b style="font-size: 12pt;">Título</b>
     <input required="required" class="caa" name="titu" placeholder="Titulo da noticia">
     <br><br>
     <b style="font-size: 12pt;">Subtitulo</b>
     <input required="required" class="caa" name="subtitu" placeholder="Exemplo: Novas mudanças!">
     <br><br>
     <b style="font-size: 12pt;">Area da Noticia</b>
     <textarea class="caa" rows="10" name="msg" placeholder="Digite... Use <br> para quebra de linhas."></textarea>
     <br><br>
     <label>Funcional em: (Inicío Painel)</label>
     <br><br>
     <button type="submit" name="adicionanoticia" class="btn-on">Adicionar</button>
	 <?php if ($procnoticias->rowCount() > 0) {
			    $noticia = $procnoticias->fetch(); ?>
	 <a href="home.php?page=apis/gerenciar&delnoti=<?php echo $noticia['id']; ?>" name="remove" class="btn-off">Desativar</a>
	<br><br>
	 <?php } ?>
	   </fieldset>
	    <?php if ($procnoticias->rowCount() > 0) { ?>
	     
          <h5 style="color: #FF4500;">Existe uma Notificacão Ativa.<br>Para editar, desative a atual antes de Adicionar!</h5>
         </center>
        </div>
       <?php } ?>
      </div>
    </form>
  </section>
  
    <div class="sales-analytics">
   <div class="item online"> 
    <form class="" action="" method="post">
  <center>
   <h2>Backup automático a cada 2minutos.</h2><h3>Por segurança baixa 2 backup!</h3><br>
   <center>   
  <?php if(file_exists("../admin/pages/apis/$DirBackup/sshplus.sql")) { ?>
    <a href="../admin/pages/apis/<?php echo $DirBackup;?>/sshplus.sql" download=""> 
	  <span class="btn">Baixar Backup</span>
        </a>
        <center>
         <?php } ?>
		   </form>
	        </div>
	         </div>
   
  <script type="text/javascript" src="/SYSTEM/sort-table.js"></script>
   <script src="/CSS/index.js"></script>
    <script src="/CSS/inde.js"></script>