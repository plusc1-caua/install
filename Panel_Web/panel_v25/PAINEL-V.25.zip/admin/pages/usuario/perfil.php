<?php


if(isset($_GET["id_usuario"])){
	$id_usuario=$_GET['id_usuario'];
	$diretorio = "../../admin/MenuSub.php?page=usuario/perfil&id_usuario=".$id_usuario;
	$SQLUsuario = "select * from usuario WHERE id_usuario = '".$id_usuario."'  ";
	$SQLUsuario = $conn->prepare($SQLUsuario);
	$SQLUsuario->execute();
	$usuario = $SQLUsuario->fetch();
	if(($SQLUsuario->rowCount()) <= 0){
		echo '<script type="text/javascript">';
		echo 	'alert("O usuario nao existe!");';
		echo	'window.location="/rev_lista.php";';
		echo '</script>';
		exit;
	}

		// avatares
	switch($usuario['avatar']){
    case 1:$avatarusu="profile-1.png";break;
    case 2:$avatarusu="profile-2.png";break;
    case 3:$avatarusu="profile-3.png";break;
    case 4:$avatarusu="profile-4.png";break;
    case 5:$avatarusu="profile-5.png";break;
    default:$avatarusu="boxed-bg.png";break;
	}

	$SQLUsuarioSSH = "select * from usuario_ssh WHERE id_usuario = '".$id_usuario."' ";
	$SQLUsuarioSSH = $conn->prepare($SQLUsuarioSSH);
	$SQLUsuarioSSH->execute();
	$total_ssh = $SQLUsuarioSSH->rowCount();



	$SQLSubrevendedores= "select * from usuario WHERE id_mestre = '".$id_usuario."' and tipo='revenda' and subrevenda='sim' ";
	$SQLSubrevendedores = $conn->prepare($SQLSubrevendedores);
	$SQLSubrevendedores->execute();
	$todossubrevendedores=$SQLSubrevendedores->rowCount();

	if (($SQLSubrevendedores->rowCount()) > 0) {

		while($subrow = $SQLSubrevendedores->fetch()) {
			$quantidade_ssh_subs=0;
			$SQLSubSSHsubs= "select * from usuario_ssh WHERE id_usuario = '".$subrow['id_usuario']."'  ";
			$SQLSubSSHsubs = $conn->prepare($SQLSubSSHsubs);
			$SQLSubSSHsubs->execute();


			$sshsubs=$SQLSubSSHsubs->rowCount();


			$SQLSubUSUARIOSsubs= "select * from usuario WHERE id_mestre = '".$subrow['id_usuario']."' ";
			$SQLSubUSUARIOSsubs = $conn->prepare($SQLSubUSUARIOSsubs);
			$SQLSubUSUARIOSsubs->execute();
			$quantidade_USUARIOS_subs += $SQLSubUSUARIOSsubs->rowCount();
			$sshsubs132=$SQLSubUSUARIOSsubs->rowCount();

		}


	}


	$total_ssh_sub = 0;

	if($usuario['tipo']=="revenda"){


		$SQLUsuarioSUB = "select * from usuario WHERE id_mestre = '".$_GET['id_usuario']."' and subrevenda='nao' ";
		$SQLUsuarioSUB = $conn->prepare($SQLUsuarioSUB);
		$SQLUsuarioSUB->execute();
		$total_user = $SQLUsuarioSUB->rowCount();

		if(($SQLUsuarioSUB->rowCount()) > 0){
			while($row_sub = $SQLUsuarioSUB->fetch()) {

				$SQLUsuarioSSH = "select * from usuario_ssh WHERE id_usuario = '".$row_sub['id_usuario']."' ";
				$SQLUsuarioSSH = $conn->prepare($SQLUsuarioSSH);
				$SQLUsuarioSSH->execute();
				$total_ssh_sub += $SQLUsuarioSSH->rowCount();


			}
			$total = $total_ssh +$total_ssh_sub;

		}

	}



	if($usuario['id_mestre']!=0 ){

		$SQLUsuario = "select * from usuario WHERE id_usuario = '".$usuario['id_mestre']."'  ";
		$SQLUsuario = $conn->prepare($SQLUsuario);
		$SQLUsuario->execute();
		$usuario_mestre = $SQLUsuario->fetch();

	}

}else{

	echo '<script type="text/javascript">';
	echo 	'alert("Preencha todos os campos!");';
	echo	'window.location="/rev_lista.php";';
	echo '</script>';
}

?>
					<script type="text/javascript">
						function excluir_usuario(){
							decisao = confirm("Tem certeza que vai excluir?!");
							if (decisao){
								window.location.href='../pages/system/funcoes.usuario.php?&op=deletar&id_usuario=<?php echo $usuario['id_usuario'];?>&diretorio=../../admin/rev_lista.php&owner=<?php echo $accessKEY;?>'
							} else {

							}
						}
						function suspende_usuario(){
							decisao = confirm("Tem certeza que vai suspender?!");
							if (decisao){
								window.location.href='../pages/system/funcoes.usuario.php?&id_usuario=<?php echo $usuario['id_usuario'];?>&diretorio=../../admin/rev_lista.php&owner=<?php echo $accessKEY;?>&op=suspender'
							} else {

							}
						}
					</script>
<main>
 <center><h1>Informações da Conta</h1></center>
 
<div class="cards">
 <div class="sales">
  <div class="linha">
 <center>
 
	<?php if($usuario['ativo'] == 2 ){?>
  <div class="suspenso">
  <h2><center>SUSPENSO</center></h2>
   </div>
    <br>
	<?php }?>
	
 <img class="profile-photo" style="width: 70px; height: 70px;" src="../../PNG/<?php echo $avatarusu;?>"> 
 <h2><?php echo $usuario['nome'];?></h2>
  <p>Tipo: Revendedor</p>
   </div>
    <center> 
     <br>
      </div>
      <div class="linha">  
 <center><h1>Ações</h1></center>
  <br>
<center>
 <button onclick="excluir_usuario()" class="botaos0">Deletar Painel</button>
 <br>
 <?php if($usuario['ativo']== 1){?>
 <button onclick="suspende_usuario()" class="botaos2">Bloquear Painel</button>
 <br>
 <?php }else{?>
 <a href="../pages/system/funcoes.usuario.php?&id_usuario=<?php echo $usuario['id_usuario'];?>&diretorio=../../admin/rev_lista.php&owner=<?php echo $accessKEY;?>&op=ususpender"><button class="botaos1">Reativar Painel</button>
 </a>
 <br>
 <?php } ?>
 <button type="submit" required="required" type="number" class="botaos3" id="dias" name="dias" value="31" > Adicionar Servidor</button></center>
  </div>
  </div>
 </form>
 <br>
  <center><h2>Editar Dados do Revenda</h2></center>
  
<div class="cards">
 <div class="sales">
 <div class="tab">
<center>
  <button class="tablinks" onclick="openCity(event, 'info')">Informações</button>
  <button class="tablinks" onclick="openCity(event, 'server')">Servidor</button>
  <button class="tablinks" onclick="openCity(event, 'user')">Conta SSH</button>
</center>
 </div>
 </div> 
 </div>
</main>
      <!----------------- END OF MAIN -------------------->
      <div class="right">
        <div class="top">
          <button id="menu-btn">
            <span class="material-icons-sharp"><ion-icon name="menu-sharp"></ion-icon></span>
          </button>
          <div class="theme-toggler">
            <span class="material-icons-sharp active">light_mode</span>
            <span class="material-icons-sharp">dark_mode</span>
          </div>
          <div class="profile">
            <div class="info">
              <p>Olá, <b><?php echo strtoupper($administrador['nome']);?></b></p>
              <small class="text-muted">Administrador</small>
            </div>
            <div class="profile-photo">
             <a href="/admin/MenuSub.php?page=admin/dados">
              <img src="/PNG/admin.png" /></a>
            </div>
          </div>
        </div>

<div id="server" class="tabcontent">
 <div class="sales-analytics">
  <div class="item online">

  <div id="timeline">
   <div class="bord">
   <form  role="servidor" name="servidor" id="servidor" action="pages/usuario/adiciona_acesso.php" method="post">
    <center><h2>Adicionar Servidor</h2></center>

     <b style="font-size: 12pt;">Servidor</b>
      <select class="caa" name="servidor" id="servidor">
       <option selected="selected" value="0">Selecione um servidor</option>
                  <?php


    $SQLServidor = "select * from servidor   ";
    $SQLServidor = $conn->prepare($SQLServidor);
    $SQLServidor->execute();

if (($SQLServidor->rowCount()) > 0) {
    // output data of each row
    while($row2 = $SQLServidor->fetch()   ) {

		$SQLAcessoServidor = "select * from acesso_servidor where id_servidor='".$row2['id_servidor']."'  and id_usuario = '".$_GET['id_usuario']."'";
        $SQLAcessoServidor = $conn->prepare($SQLAcessoServidor);
        $SQLAcessoServidor->execute();


		if(($SQLAcessoServidor->rowCount()) == 0 ){
		?>

	<option value="<?php echo $row2['id_servidor'];?>" > <?php echo $row2['nome'];?> </option>

		<?php
		}
   }
}


?>
   </select>
    <br><br>
      
      <div id="qtd_ssh" >
       <b style="font-size: 12pt;">Limite de Acessos</b>
        <input required="required" type="number" class="caa" id="qtd" name="qtd" placeholder="Digite a quantidade">
         </div>
        <br>
        
       <div id="qtd_ssh" >
        <b style="font-size: 12pt;">Data de Validade</b>
         <input required="required" type="text" class="caa" id="val" name="val" placeholder="Exemplo: 15 (dias)">
       </div>
       
	    <div id="qtd_ssh" >	   
         <input  type="hidden" class="caa" id="usuario" name="usuario" value="<?php echo $_GET['id_usuario'];?>">
         </div>
         <br>
        <button type="submit" class="btn">Adicionar</button>
        <button type="reset" class="bt">Resetar</button>
       </form>
      </div>
     <br>
     <?php
    $usuarioid=anti_sql_injection($_GET['id_usuario']);
    $SQLverifica = "select * from acesso_servidor where id_usuario='".$usuarioid."'";
    $SQLverifica = $conn->prepare($SQLverifica);
    $SQLverifica->execute();
    if($SQLverifica->rowCount()>0){
        ?>
    <hr>
    
   <div class="bord">
   <form  role="servidor" name="servidor" id="servidor" action="pages/usuario/edita_acesso.php" method="post">
    <center><h2>Editar Servidor</h2></center>

     <b style="font-size: 12pt;">Servidor</b>
      <select class="caa" name="servidor" id="servidor">
       <option selected="selected" value="0">Selecione um servidor</option>
                  <?php

    $usuarioid=anti_sql_injection($_GET['id_usuario']);
    $SQLServidor2 = "select * from acesso_servidor where id_usuario='".$usuarioid."'";
    $SQLServidor2 = $conn->prepare($SQLServidor2);
    $SQLServidor2->execute();

if (($SQLServidor2->rowCount()) > 0) {
    // output data of each row
    while($row22 = $SQLServidor2->fetch()   ) {

		$SQLAcessoServidor2 = "select * from servidor where id_servidor='".$row22['id_servidor']."'";
        $SQLAcessoServidor2 = $conn->prepare($SQLAcessoServidor2);
        $SQLAcessoServidor2->execute();


		if(($SQLAcessoServidor2->rowCount()) > 0 ){
		$server = $SQLAcessoServidor2->fetch();
		?>

	<option value="<?php echo $row22['id_acesso_servidor'];?>" > <?php echo $server['nome'];?> </option>

		<?php
		}
   }
}


?>
   </select>
    <br><br>
      
      <div id="qtd_ssh" >
       <b style="font-size: 12pt;">Adicionar Dias (validade)</b>
        <input required="required" type="text" class="caa" id="val" name="val" value="0">
         </div>
        <br>
        
      <b style="font-size: 12pt;">Adicionar Limite</b>
       <input type="number" class="caa" id="acesso" name="acesso" value="0">
        <br><br>
       
        <b style="font-size: 12pt;">Remover Limite</b>
         <input required="required" type="number" class="caa" id="racesso" name="racesso" value="0">
           
	     <div id="qtd_ssh" >
	      <input  type="hidden" class="caa" id="usuario" name="usuario" value="<?php echo $_GET['id_usuario'];?>">
         </div>
         
         <br>
        <button type="submit" class="btn">Adicionar</button>
        <button type="reset" class="bt">Resetar</button>
       </form>
      <br>
    </div>
    <?php } ?>
   </div>
  </div>
 </div>
 
    <div class="recent-orders">
      <center><h2>Servidores do revenda</h2></center>
         <div class="scroller">
          <table class="js-sort-table" id="customers">
														<tr>
															<th>SERVER</th>
															<th>LIMITE</th>
															<th>VALIDO</th>
															<th>CRIADO</th>
															<th>USADO</th>
															<th>EXCLUIR</th>

														</tr>
														<?php


														$SQLAcessoServidor = "select * from acesso_servidor where id_usuario='".$_GET['id_usuario']."'  ";
														$SQLAcessoServidor = $conn->prepare($SQLAcessoServidor);
														$SQLAcessoServidor->execute();


														if (($SQLAcessoServidor->rowCount()) > 0) {


															while($row2 = $SQLAcessoServidor->fetch()   ){

																$SQLTotalUser = "select * from usuario WHERE id_usuario = '".$_GET['id_usuario']."' ";
																$SQLTotalUser = $conn->prepare($SQLTotalUser);
																$SQLTotalUser->execute();
																$total_user = $SQLTotalUser->rowCount();



																$SQLServidor = "select * from servidor where id_servidor = '".$row2['id_servidor']."'";
																$SQLServidor = $conn->prepare($SQLServidor);
																$SQLServidor->execute();

																$SQLsubservidores = "select * from acesso_servidor WHERE id_servidor_mestre = '".$row2['id_acesso_servidor']."'";
																$SQLsubservidores = $conn->prepare($SQLsubservidores);
																$SQLsubservidores->execute();
																$total_subservers = $SQLsubservidores->rowCount();

																$contas=0;
																$acessos=0;


																$SQLUsuarioSSH = "select * from usuario_ssh WHERE id_servidor = '".$row2['id_servidor']."'
																and id_usuario='".$_GET['id_usuario']."'  ";
																$SQLUsuarioSSH = $conn->prepare($SQLUsuarioSSH);
																$SQLUsuarioSSH->execute();
																$contas += $SQLUsuarioSSH->rowCount();

																$SQLAcessoSSH = "SELECT sum(acesso) AS quantidade  FROM usuario_ssh where id_servidor = '".$row2['id_servidor']."'  and id_usuario='".$_GET['id_usuario']."' ";
																$SQLAcessoSSH = $conn->prepare($SQLAcessoSSH);
																$SQLAcessoSSH->execute();
																$SQLAcessoSSH = $SQLAcessoSSH->fetch();
																$acessos += $SQLAcessoSSH['quantidade'];



																$SQLUsuarioSub = "select * from usuario WHERE id_mestre = '".$_GET['id_usuario']."' and subrevenda='nao' ";
																$SQLUsuarioSub = $conn->prepare($SQLUsuarioSub);
																$SQLUsuarioSub->execute();

																if (($SQLUsuarioSub->rowCount()) > 0) {
																	while($row3 = $SQLUsuarioSub->fetch()   ){

																		$SQLUsuarioSSH = "select * from usuario_ssh WHERE id_servidor = '".$row2['id_servidor']."'
																		and id_usuario='".$row3['id_usuario']."'  ";
																		$SQLUsuarioSSH = $conn->prepare($SQLUsuarioSSH);
																		$SQLUsuarioSSH->execute();
																		$contas += $SQLUsuarioSSH->rowCount();

																		$SQLAcessoSSH = "SELECT sum(acesso) AS quantidade  FROM usuario_ssh where id_servidor = '".$row2['id_servidor']."'  and id_usuario='".$row3['id_usuario']."' ";
																		$SQLAcessoSSH = $conn->prepare($SQLAcessoSSH);
																		$SQLAcessoSSH->execute();
																		$SQLAcessoSSH = $SQLAcessoSSH->fetch();
																		$acessos += $SQLAcessoSSH['quantidade'];



																	}
																}





																if (($SQLServidor->rowCount()) > 0) {
																	while($row3 = $SQLServidor->fetch()   ){

																		$qtd_srv =0;

			//Calcula os dias restante
																		$data_atual = date("Y-m-d");
																		$data_validade = $row2['validade'];
																		if($data_validade > $data_atual){
																			$data1 = new DateTime( $data_validade );
																			$data2 = new DateTime( $data_atual );
																			$dias_acesso = 0;
																			$diferenca = $data1->diff( $data2 );
																			$ano = $diferenca->y * 364 ;
																			$mes = $diferenca->m * 30;
																			$dia = $diferenca->d;
																			$dias_acesso = $ano + $mes + $dia;

																		}else{
																			$dias_acesso = 0;
																		}

						?>

					    <tr>
						<td><?php echo $row3['nome'];?></td>
						<td><?php echo $row2['qtd'];?></td>
			        	<td><?php echo $dias_acesso." dias"; ?></td>
				    	<td><?php echo $contas;?></td>
				    	<td><?php echo $acessos;?></td>
						<td>
				    	<script>
																						function apaga_tudo<?php echo $row2['id_acesso_servidor'];?>(){
																							decisao = confirm("Tem certeza que vai apagar o servidor dele?!\n Vai apagar o servidor dos subrevendedores dele.");
					if (decisao){
				window.location.href='pages/usuario/remover_servidor.php?&id_acesso=<?php echo $row2['id_acesso_servidor'];?>'
							} else {

								}
								 	}
								     	</script>
								     	
                     <a onclick="apaga_tudo<?php echo $row2['id_acesso_servidor'];?>()" >
                     <button class="botao1">
                     <ion-icon name="trash-bin"></ion-icon>
                     </button>
                     </a>
		        	</td>

				</tr>
<?php
																	}
																}
															}
														}
														?>

	</table>
   </div>  
  </div> 
 </div>

<div class="sales-analytics">
 <div id="info" class="tabcontent">
  <form class="form-horizontal"  role="perfil" name="perfil" id="perfil" action="pages/usuario/editar_exe.php" method="post" >
   <div class="item online">
    <div class="bord">
     <center><h2>Dados do Revenda</h2></center>

 <b style="font-size: 12pt;">Login</b>
  <input type="text" class="caa" disabled value="<?php echo $usuario['login'];?>">
  <input type="hidden" class="caa" id="idusuario" name="idusuario" value="<?php echo $usuario['id_usuario'];?>">
<br><br>

 <b style="font-size: 12pt;">Nome</b>
  <input type="text" class="caa" id="nome" name="nome" value="<?php echo $usuario['nome'];?>">
<br><br>

 <b style="font-size: 12pt;">Senha</b>
  <input type="password" class="caa" id="senha" name="senha" value="<?php echo $usuario['senha'];?>">
<br><br>

 <b style="font-size: 12pt;">Email</b>
  <input type="email" class="caa" id="email" name="email" value="<?php echo $usuario['email'];?>">
<br><br>

 <b style="font-size: 12pt;">Celular</b>
  <input type="text" class="caa" id="celular" name="celular" value="<?php echo $usuario['celular'];?>">
<br><br>
      
 <b style="font-size: 12pt;">Data Cadastro</b>
  <input type="text" class="caa" disabled value="<?php echo $usuario['data_cadastro'];?>">
<br><br>                                       

  <button type="submit" class="btn">Alterar Dados</button>
  <button type="reset" class="bt">Resetar</button>
    </form>
   </div>
  </div>
 </div>

<div id="user" class="tabcontent">
    <div class="recent-orders">
      <center><h1>Usuarios do revenda</h1></center>
         <div class="scroller">
          <table class="js-sort-table" id="customers">
												<tr>
													<th>LOGIN</th>
													<th>SERVIDOR</th>
													<th>LIMITE</th>
													<th>EDITAR</th>
												</tr>
												<?php
												$SQLUsuarioSSH = "select * from usuario_ssh where id_usuario='".$usuario['id_usuario']."'";
												$SQLUsuarioSSH = $conn->prepare($SQLUsuarioSSH);
												$SQLUsuarioSSH->execute();


												if (($SQLUsuarioSSH->rowCount()) > 0) {

    // output data of each row
													while($row_user = $SQLUsuarioSSH->fetch()   ){

														$SQLServidor = "select * from servidor where id_servidor='".$row_user['id_servidor']."'  ";
														$SQLServidor = $conn->prepare($SQLServidor);
														$SQLServidor->execute();
														$servidor = $SQLServidor->fetch();
														$color = "";

														$acessos = 0;
														$SQLAcessoSSH = "SELECT sum(acesso) AS quantidade  FROM usuario_ssh where id_usuario_ssh='".$row_user['id_usuario_ssh']."' ";
														$SQLAcessoSSH = $conn->prepare($SQLAcessoSSH);
														$SQLAcessoSSH->execute();
														$SQLAcessoSSH = $SQLAcessoSSH->fetch();
														$acessos += $SQLAcessoSSH['quantidade'];


														if($row_user['status']== 2){

															$color = "bgcolor='#FF6347'";
														}



														?>


									        <tr <?php echo $color; ?>>
											<td><?php echo $row_user['login'];?></td>
										    <td><?php echo $servidor['nome'];?></td>
										    <td><?php echo $acessos;?></td>
											
                      <td>
                     <a href="/SubMenu.php?page=ssh/editar&id_ssh=<?php echo $row['id_usuario_ssh'];?>">
                     <button class="botao2">
                     <ion-icon name="brush"></ion-icon>
                     </button>
                     </a>
                      </td>


														</tr>

														<?php


													}
												}
												if($usuario['tipo'] == "revenda"){

													$SQLUserSub = "select * from usuario where id_mestre = '".$usuario['id_usuario']."'  ";
													$SQLUserSub = $conn->prepare($SQLUserSub);
													$SQLUserSub->execute();

													if (($SQLUserSub->rowCount()) > 0) {

														while($row_user_sub = $SQLUserSub->fetch()   ){


															$SQLSubSSH = "select * from usuario_ssh where id_usuario='".$row_user_sub['id_usuario']."'  ";
															$SQLSubSSH = $conn->prepare($SQLSubSSH);
															$SQLSubSSH->execute();

															if (($SQLSubSSH->rowCount()) > 0) {
																while($row_ssh_sub = $SQLSubSSH->fetch()   ){

																	$SQLServidor = "select * from servidor where id_servidor='".$row_ssh_sub['id_servidor']."'  ";
																	$SQLServidor = $conn->prepare($SQLServidor);
																	$SQLServidor->execute();
																	$servidor = $SQLServidor->fetch();
																	$color = "";
																	$acessos  = 0;

																	if($row_ssh_sub['status']== 2){

																		$color = "bgcolor='#FF6347'";
																	}

																	$SQLAcessoSSH = "SELECT sum(acesso) AS quantidade  FROM usuario_ssh where id_usuario_ssh='".$row_ssh_sub['id_usuario_ssh']."'  ";
																	$SQLAcessoSSH = $conn->prepare($SQLAcessoSSH);
																	$SQLAcessoSSH->execute();
																	$SQLAcessoSSH = $SQLAcessoSSH->fetch();
																	$acessos += $SQLAcessoSSH['quantidade'];


																	?>
																<?php	}

															}
														}

													}

												}


												?>

	</table>
    </div>
  </div>
 </div>
</div>

<style>
hr {
    width: 100%;
    height: 1px;
    border-radius: 8px;
    border-top: 2px solid #1C1C1C;
}
</style>
  <script type="text/javascript" src="/SYSTEM/sort-table.js"></script>
   <script src="/CSS/index.js"></script>
    <script src="/CSS/inde.js"></script>