<!DOCTYPE html>
<html>
<head>
	<title>Login Painel</title>
	<link rel="stylesheet" type="text/css" href="CSS/login.css">
	<link href="https://fonts.googleapis.com/css?family=Poppins:600&display=swap" rel="stylesheet">
	<script src="https://kit.fontawesome.com/a81368914c.js"></script>
	<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
	<img class="wave" src="PNG/inicial/fundo.png">
	<div class="container">
		<div class="img">
			<img src="PNG/inicial/icon.svg">
		</div>
		<div class="login-content">
			<form method="post" action="logando.php">
				<img src="PNG/inicial/avatar.svg">
				<h2 class="title">Bem Vindo!</h2>
           		<div class="input-div one">
           		   <div class="i">
           		   		<i class="fas fa-user"></i>
           		   </div>
           		   <div class="div">
           		   		<h5>Usuário</h5>
           		   		<input type="text" class="input" id="login" name="login">
           		   </div>
           		</div>
           		<div class="input-div pass">
           		   <div class="i"> 
           		    	<i class="fas fa-lock"></i>
           		   </div>
           		   <div class="div">
           		    	<h5>Senha</h5>
           		    	<input type="password" class="input" id="senha" name="senha">
            	   </div>
            	</div>
            	<a href="#">Não possui um conta? Cadastre-se</a>
            	<input type="submit" name="botaologin" class="btn" value="Login">
            </form>
        </div>
    </div>
    <script type="text/javascript" src="CSS/login.js"></script>
</body>
</html>
