<?php


require_once("pages/system/seguranca.php");
require_once("pages/system/config.php");
require_once("pages/system/classe.ssh.php");

protegePagina("user");


$quantidade_ssh = 0;
$quantidade_ssh_user =0;
$quantidade_ssh_sub =0;
$quantidade_sub = 0;
$all_ssh_susp_qtd = 0;

$SQLUsuario = "SELECT * FROM usuario WHERE id_usuario = '".$_SESSION['usuarioID']."'";
$SQLUsuario = $conn->prepare($SQLUsuario);
$SQLUsuario->execute();
$usuario = $SQLUsuario->fetch();
// avatares
switch($usuario['avatar']){
    case 1:$avatarusu="profile-1.png";break;
    case 2:$avatarusu="profile-2.png";break;
    case 3:$avatarusu="profile-3.png";break;
    case 4:$avatarusu="profile-4.png";break;
    case 5:$avatarusu="profile-5.png";break;
    default:$avatarusu="boxed-bg.png";break;
}


if($usuario['tipo']=='revenda'){
    $tipouser='Revendedor';
}elseif($usuario['tipo']=='vpn'){
    $tipouser='Usuário VPN';
}

$datacad=$usuario['data_cadastro'];

$partes = explode("-", $datacad);
$ano = $partes[0];
$mes = $partes[1];

$Mes = muda_mes($mes);
$Meses = muda_mes2($mes);

#####################
// Usados

 $qtddoserverusado=0;

 $SQLusuariosdele= "SELECT * FROM usuario where id_mestre = '".$_SESSION['usuarioID']."' and subrevenda='nao'";
 $SQLusuariosdele = $conn->prepare($SQLusuariosdele);
 $SQLusuariosdele->execute();

 if ($SQLusuariosdele->rowCount()>0) {
  while($usuariosdele=$SQLusuariosdele->fetch()){
    $SQLcontaqtdsshusadodele= "SELECT sum(acesso) as acessosdosserversusados2 FROM usuario_ssh where id_usuario = '".$usuariosdele['id_usuario']."'";
    $SQLcontaqtdsshusadodele = $conn->prepare($SQLcontaqtdsshusadodele);
    $SQLcontaqtdsshusadodele->execute();

    $qtdusadosdele=$SQLcontaqtdsshusadodele->fetch();

    $qtddoserverusado+=$qtdusadosdele['acessosdosserversusados2'];

  }

}


$SQLcontaqtdsshusado= "SELECT sum(acesso) as acessosdosserversusados FROM usuario_ssh where id_usuario = '".$_SESSION['usuarioID']."'";
$SQLcontaqtdsshusado = $conn->prepare($SQLcontaqtdsshusado);
$SQLcontaqtdsshusado->execute();

$qtdusados=$SQLcontaqtdsshusado->fetch();

$qtddoserverusado+=$qtdusados['acessosdosserversusados'];


// Todos Acessos

$todosacessos=0;

$SQLqtdserveracessos= "SELECT sum(qtd) as todosacessos FROM  acesso_servidor where id_usuario = '".$_SESSION['usuarioID']."'";
$SQLqtdserveracessos = $conn->prepare($SQLqtdserveracessos);
$SQLqtdserveracessos->execute();

$totalacess=$SQLqtdserveracessos->fetch();

$todosacessos+=$totalacess['todosacessos'];

//Disponiveis
$disponiveis=$todosacessos-$qtddoserverusado;

if($disponiveis<=0){$disponiveis=0;}

//Calculo Porcentagem

$porcent = ($qtddoserverusado/$todosacessos)*100; // %

$resultado = $porcent;

$valor_porce = round($resultado);

if($valor_porce>=100){
  $valor_porce=100;
}

if($valor_porce<=0){
  $valor_porce=0;
}

if(($valor_porce>=70)and($valor_porce<90)){
  $sucessobar="warning";
  $bgbar="orange";
}elseif($valor_porce>=90){
  $sucessobar="danger";
  $bgbar="red";
}else{
  $sucessobar="success";
  $bgbar="green";
}

#####################

$SQLUsuario_ssh = "select * from usuario_ssh WHERE id_usuario = '".$_SESSION['usuarioID']."' ";
$SQLUsuario_ssh = $conn->prepare($SQLUsuario_ssh);
$SQLUsuario_ssh->execute();
$quantidade_ssh += $SQLUsuario_ssh->rowCount();

$SQLUsuario_sshSUSP = "select * from usuario_ssh WHERE id_usuario = '".$_SESSION['usuarioID']."' and  status='2' and apagar='0' ";
$SQLUsuario_sshSUSP = $conn->prepare($SQLUsuario_sshSUSP);
$SQLUsuario_sshSUSP->execute();
$all_ssh_susp_qtd += $SQLUsuario_sshSUSP->rowCount();

$total_acesso_ssh = 0;
$SQLAcessoSSH = "SELECT sum(acesso) AS quantidade  FROM usuario_ssh where id_usuario='".$_SESSION['usuarioID']."' ";
$SQLAcessoSSH = $conn->prepare($SQLAcessoSSH);
$SQLAcessoSSH->execute();
$SQLAcessoSSH = $SQLAcessoSSH->fetch();
$total_acesso_ssh += $SQLAcessoSSH['quantidade'];

$total_acesso_ssh_online = 0;
$SQLAcessoSSH = "SELECT sum(online) AS quantidade  FROM usuario_ssh  where id_usuario='".$_SESSION['usuarioID']."' ";
$SQLAcessoSSH = $conn->prepare($SQLAcessoSSH);
$SQLAcessoSSH->execute();
$SQLAcessoSSH = $SQLAcessoSSH->fetch();
$total_acesso_ssh_online += $SQLAcessoSSH['quantidade'];




$SQLAcesso= "select * from acesso_servidor WHERE id_usuario = '".$_SESSION['usuarioID']."' ";
$SQLAcesso = $conn->prepare($SQLAcesso);
$SQLAcesso->execute();
$acesso_servidor = $SQLAcesso->rowCount();

// Notificações
$SQLnoti= "select * from  notificacoes where lido='nao' and usuario_id='".$_SESSION['usuarioID']."'";
$SQLnoti = $conn->prepare($SQLnoti);
$SQLnoti->execute();
$totalnoti = $SQLnoti->rowCount();
// Notificações Contas
$SQLnoti1= "select * from  notificacoes where lido='nao' and tipo='conta' and usuario_id='".$_SESSION['usuarioID']."'";
$SQLnoti1= $conn->prepare($SQLnoti1);
$SQLnoti1->execute();
$totalnoti_contas = $SQLnoti1->rowCount();

if($usuario['tipo']=='revenda'){
    // Notificações Revenda
    $SQLnoti3= "select * from  notificacoes where lido='nao' and tipo='revenda' and usuario_id='".$_SESSION['usuarioID']."'";
    $SQLnoti3= $conn->prepare($SQLnoti3);
    $SQLnoti3->execute();
    $totalnoti_revenda = $SQLnoti3->rowCount();

    //Todos os chamados subRevendedores e usuarios do revendedor
    $SQLchamadoscli2= "select * from  chamados where status='resposta' and id_mestre='".$_SESSION['usuarioID']."'";
    $SQLchamadoscli2= $conn->prepare($SQLchamadoscli2);
    $SQLchamadoscli2->execute();
    $all_chamados_clientes += $SQLchamadoscli2->rowCount();
    //Todos os chamados subRevendedores e usuarios do revendedor
    $SQLchamadoscli= "select * from  chamados where status='aberto' and id_mestre='".$_SESSION['usuarioID']."'";
    $SQLchamadoscli= $conn->prepare($SQLchamadoscli);
    $SQLchamadoscli->execute();
    $all_chamados_clientes += $SQLchamadoscli->rowCount();

    //subrevendedores
    $SQLsbrevenda = "select * from usuario WHERE id_mestre = '".$_SESSION['usuarioID']."' and subrevenda='sim' ";
    $SQLsbrevenda = $conn->prepare($SQLsbrevenda);
    $SQLsbrevenda->execute();
    $quantidade_sub_revenda = $SQLsbrevenda->rowCount();
}

//Todos os chamados meus 1
$SQLchamados= "select * from  chamados where status='aberto' and usuario_id='".$_SESSION['usuarioID']."'";
$SQLchamados= $conn->prepare($SQLchamados);
$SQLchamados->execute();
$all_chamados += $SQLchamados->rowCount();
//Todos os chamados meus 2
$SQLchamados2= "select * from  chamados where status='resposta' and usuario_id='".$_SESSION['usuarioID']."'";
$SQLchamados2= $conn->prepare($SQLchamados2);
$SQLchamados2->execute();
$all_chamados += $SQLchamados2->rowCount();
// Notificações chamados
$SQLnotichama= "select * from  notificacoes where lido='nao' and tipo='chamados' and usuario_id='".$_SESSION['usuarioID']."'";
$SQLnotichama= $conn->prepare($SQLnotichama);
$SQLnotichama->execute();
$totalnoti_chamados = $SQLnotichama->rowCount();
// Notificações Outros
$SQLnoti4= "select * from  notificacoes where lido='nao' and tipo='outros' and usuario_id='".$_SESSION['usuarioID']."'";
$SQLnoti4= $conn->prepare($SQLnoti4);
$SQLnoti4->execute();
$totalnoti_outros = $SQLnoti4->rowCount();

if($usuario['id_mestre']<>0){
    // Notificações users
    $SQLnoti5= "select * from  notificacoes where lido='nao' and tipo='usuario' and usuario_id='".$_SESSION['usuarioID']."'";
    $SQLnoti5= $conn->prepare($SQLnoti5);
    $SQLnoti5->execute();
    $totalnoti_users = $SQLnoti5->rowCount();


}


if($usuario['tipo']=="revenda"){
    $SQLSub= "select * from usuario WHERE id_mestre = '".$_SESSION['usuarioID']."' and subrevenda='nao'";
    $SQLSub = $conn->prepare($SQLSub);
    $SQLSub->execute();


    if (($SQLSub->rowCount()) > 0) {

        while($row = $SQLSub->fetch()) {

            $SQLSubSSH= "select * from usuario_ssh WHERE id_usuario = '".$row['id_usuario']."'  ";
            $SQLSubSSH = $conn->prepare($SQLSubSSH);
            $SQLSubSSH->execute();
            $quantidade_ssh += $SQLSubSSH->rowCount();

            $sshsub=$SQLSubSSH->rowCount();

            $SQLUsuario_sshSUSP = "select * from usuario_ssh WHERE id_usuario = '".$row['id_usuario']."' and status='2' and apagar='0' ";
            $SQLUsuario_sshSUSP = $conn->prepare($SQLUsuario_sshSUSP);
            $SQLUsuario_sshSUSP->execute();
            $all_ssh_susp_qtd += $SQLUsuario_sshSUSP->rowCount();

            $SQLAcessoSSH = "SELECT sum(acesso) AS quantidade  FROM usuario_ssh where id_usuario='".$row['id_usuario']."' ";
            $SQLAcessoSSH = $conn->prepare($SQLAcessoSSH);
            $SQLAcessoSSH->execute();
            $SQLAcessoSSH = $SQLAcessoSSH->fetch();
            $total_acesso_ssh += $SQLAcessoSSH['quantidade'];


            $SQLAcessoSSHon = "SELECT sum(online) AS quantidade  FROM usuario_ssh  where id_usuario='".$row['id_usuario']."' ";
            $SQLAcessoSSHon = $conn->prepare($SQLAcessoSSHon);
            $SQLAcessoSSHon->execute();
            $SQLAcessoSSHon = $SQLAcessoSSHon->fetch();
            $total_acesso_ssh_online += $SQLAcessoSSHon['quantidade'];

        }


    }
    $quantidade_sub += $SQLSub->rowCount();


    //Calcula os dias restante
    $data_atual = date("Y-m-d ");
    $data_validade = $usuario['validade'];

    $data1 = new DateTime( $data_validade );
    $data2 = new DateTime( $data_atual );

    $diferenca = $data1->diff( $data2 );
    $ano = $diferenca->y * 364 ;
    $mes = $diferenca->m * 30;
    $dia = $diferenca->d;
    $dias_acesso = $ano + $mes + $dia;

    $quantidade_ssh +=   $quantidade_ssh_sub+$quantidade_ssh_user;

    if($usuario['ativo']==2){
        echo '<script type="text/javascript">';
        echo   'alert("Sua conta  esta suspensa!");';
        echo 'window.location="pages/suspenso.php";';
        echo '</script>';
        exit;

    }

}

?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Painel Web</title>
    <!-- MATERIAL CDN -->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Sharp" rel="stylesheet" />
	<link rel="icon" type="image/png" sizes="18x18" href="/PNG/inicial/avatar.svg">
    <script src="https://unpkg.com/ionicons@5.1.2/dist/ionicons.js"></script>
    <script src="http://code.jquery.com/jquery-latest.js"></script>
    <!-- STYLESHEET -->
    <link rel="stylesheet" href="/CSS/style.css" />
    <link rel="stylesheet" href="/SYSTEM/select.css" />
    <link rel="stylesheet" href="/SYSTEM/config.css" />
    <link rel="stylesheet" href="/SYSTEM/config2.css" />
    <link rel="stylesheet" href="/SYSTEM/config3.css" />
    <link rel="stylesheet" href="/SYSTEM/login-add.css" />
    
  </head>
  <body>
    <div class="container">
        <script>
  //paste this code under head tag or in a seperate js file.
  // Wait for window load
  $(window).load(function() {
    // Animate loader off screen
    $(".se-pre-con").fadeOut('slow');;
  });
</script>
<script>
  function usuariosonline()
  {

  $.post('pages/ssh/online_home.php?requisicao=1',
    function (resposta) {
    
          $("#usuarioson").fadeOut("slow").fadeIn('slow');
          
      $('#usuarioson').empty();
      
      $('#usuarioson').append(resposta);
    });
}

setInterval("usuariosonline()", 10000);

$(function() {

    usuariosonline();
  });
</script>
<script>
  function atualizar()
  {
  
    $.post('pages/ssh/online_home.php?requisicao=2',
      function (online) {
      
        $('#online_nav').html(online);
        $('#online').html(online);

      }, 'JSON');
  }
  
setInterval("atualizar()", 1000);

$(function() {

    atualizar();
  });
</script>
      <aside>
        <div class="top">
          <div class="logo">
            <img src="/PNG/logo.png" />
            <h2 cla>C1-<span class="danger">PLUS</span></h2>
          </div>
          <div class="close" id="close-btn">
            <span class="material-icons-sharp">close</span>
          </div>
        </div>
        <div class="sidebar">
          <a href="/home.php" class="active">
            <span class="material-icons-sharp">grid_view</span>
            <h3>Dashboard</h3>
          </a>
          
          <a href="/user_add_teste.php">
            <span class="material-icons-sharp"><ion-icon name="person-add-sharp"></ion-icon></span>
            <h3>ADD User Teste</h3>
          </a>
          
          <a href="/user_add.php">
            <span class="material-icons-sharp"><ion-icon name="person-add-sharp"></ion-icon></span>
            <h3>ADD User Mensal</h3>
          </a>
                    
          <a href="/user_lista.php">
            <span class="material-icons-sharp"><ion-icon name="person-sharp"></ion-icon></span>
            <h3>Listar User Criado</h3>
            <span class="message-count"><?php echo $quantidade_ssh; ?></span>
          </a>
          
          <a href="/server.php">
            <span class="material-icons-sharp"><ion-icon name="server"></ion-icon></span>
            <h3>Listar Servidor</h3>
            <span class="message-count"><?php echo $acesso_servidor; ?></span>
          </a>          
          
          <a href="/historico.php">
            <span class="material-icons-sharp"><ion-icon name="alert-circle-sharp"></ion-icon></span>
            <h3>Histórico</h3>
            <span class="message-count"><?php echo $totalnoti_contas;?></span>
          </a>
          
          <a href="#">
            <span class="material-icons-sharp"><ion-icon name="mail-sharp"></ion-icon></span>
            <h3>Email</h3>
          </a>
          
          <a href="/SubMenu.php?page=admin/dados">
            <span class="material-icons-sharp"><ion-icon name="settings-sharp"></ion-icon></span>
            <h3>Configuração</h3>
          </a>
          
          <a href="sair.php" class="active">
            <span class="material-icons-sharp"><ion-icon name="log-out-sharp"></ion-icon></span>
            <h3>Log Out</h3>
         </a>
       </div>
     </aside>
      <main>
        <?php


        if(isset($_GET["page"])){
            $page = $_GET["page"];
            if($page and file_exists("".$page.".php")) {
                include("".$page.".php");
            } else {
                include("home_notify.php");
            }
        }else{
            include("home_notify.php");
        }

        ?>
        