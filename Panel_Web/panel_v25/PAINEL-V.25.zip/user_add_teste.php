<?php
include("SubMenu.php")
?>
      <main>
        <center>
        <h1>Criar Usuário Teste</h1>
        </center>
        <form data-toggle="validator" action="../pages/system/conta.ssh.php" method="POST" role="form">
        <div class="cards">
          
            <div class="textfield" style="display:none;">
            <h3>Gerenciador</h3>
       <select name="usuario" id="usuario">
       <option selected="selected" value="<?php echo $_SESSION['usuarioID']; ?>">Usuário Atual do Sistema</option>
       <?php
                                            $SQL = "SELECT * FROM usuario where id_mestre = '".$_SESSION['usuarioID']."'";
                                            $SQL = $conn->prepare($SQL);
                                            $SQL->execute();

                                            if (($SQL->rowCount()) > 0) {
                                                // output data of each row
                                                while($row = $SQL->fetch()) {?>

                                                    <option value="<?php echo $row['id_usuario'];?>" ><?php echo $row['login'];?></option>

                                                <?php }
                                            }

                                            ?>
       </select>
          </div>
          
         <div class="textfield">
          <h3>Servidor</h3>
       <select class="select" name="acesso_servidor" id="acesso_servidor">
       <option selected="selected">Selecione um Servidor</option>
       <?php
                                            $SQLAcesso= "select * from acesso_servidor WHERE id_usuario = '".$usuario['id_usuario']."' ";
                                            $SQLAcesso = $conn->prepare($SQLAcesso);
                                            $SQLAcesso->execute();
                                            if (($SQLAcesso->rowCount()) > 0) {
                                                // output data of each row
                                                while($row_srv = $SQLAcesso->fetch()) {
                                                    $contas_ssh_criadas = 0;

                                                    $SQLServidor = "select * from servidor WHERE id_servidor = '".$row_srv['id_servidor']."' ";
                                                    $SQLServidor = $conn->prepare($SQLServidor);
                                                    $SQLServidor->execute();
                                                    $servidor = $SQLServidor->fetch();


                                                    $SQLContasSSH = "SELECT sum(acesso) AS quantidade  FROM usuario_ssh where id_servidor = '".$row_srv['id_servidor']."' and id_usuario='".$_SESSION['usuarioID']."' ";
                                                    $SQLContasSSH = $conn->prepare($SQLContasSSH);
                                                    $SQLContasSSH->execute();
                                                    $SQLContasSSH = $SQLContasSSH->fetch();
                                                    $contas_ssh_criadas += $SQLContasSSH['quantidade'];

                                                    $SQLSub= "select * from usuario WHERE id_mestre = '".$_SESSION['usuarioID']."' ";
                                                    $SQLSub = $conn->prepare($SQLSub);
                                                    $SQLSub->execute();

                                                    $resta=$row_srv['qtd']-$contas_ssh_criadas;

                                                    ?>
                                                    <option value="<?php echo $row_srv['id_acesso_servidor'];?>"> <?php echo $servidor['nome'];?> - Resta <?php echo $resta;?> de <?php echo $row_srv['qtd'];?></option>
                                                <?php }
                                            }
                                            ?>
       </select>
         </div>
            
          <div class="textfield">
          <h3>Tempo</h3>
       <select class="select" name="tempuser" id="tempuser">
       <option selected="selected" value="24h">24 horas (recomendado)</option>
          </select>
       <input type="hidden" name="dias" id="dias" class="form-control" value="1">
         </div>

         <div class="textfield">
        <h3>Usuário</h3>
       <input type="text" name="login_ssh" id="login_ssh" class="form-control" placeholder="Digite a Usuario" minlength="4">
            </div>
            
         <div class="textfield">
        <h3>Senha</h3>
       <input type="password" class="form-control" name="senha_ssh" id="senha_ssh" placeholder="Digite a Senha">
            </div>
            
         <div class="textfield">
        <h3>Limite</h3>
       <input type="text" name="acessos" id="acessos" class="form-control" placeholder="Conexões Simultânea" value="1">
            </div>
            
       <input  type="hidden" class="form-control" id="diretorio" name="diretorio" value="/user_add_teste.php">
       <input  type="hidden" class="form-control" id="owner" name="owner" value="<?php echo $_SESSION['usuarioID'];?>">
         <center>
       <button name="botaologin" class="btn-login" type="submit">Criar</button>
       <button name="botaologin" class="btn-login" type="reset">Limpar</button>
         </center>
          </div>
         </form>
       </main>
      <!----------------- END OF MAIN -------------------->
      <div class="right">
        <div class="top">
          <button id="menu-btn">
            <span class="material-icons-sharp"><ion-icon name="menu-sharp"></ion-icon></span>
          </button>
          <div class="theme-toggler">
            <span class="material-icons-sharp active">light_mode</span>
            <span class="material-icons-sharp">dark_mode</span>
          </div>
          <div class="profile">
            <div class="info">
              <p>Olá, <b><?php echo strtoupper($usuario['nome']);?></b></p>
              <small class="text-muted"><?php echo $tipouser;?></small>
            </div>
            <div class="profile-photo">
             <a href="/SubMenu.php?page=admin/dados">
              <img src="/PNG/<?php echo $avatarusu;?>" /></a>
            </div>
          </div>
        </div>
        <!-- END OF TOP -->
        <div class="sales-analytics">
          <h2>Progresso de Uso</h2>
          <div class="item online">
            <div class="icon">
              <span class="material-icons-sharp"><ion-icon name="stats-chart-outline"></ion-icon></span>
            </div>
            <div class="right">
              <div class="info">
                <h3>Limite Total</h3>
              </div>
              <h3 class="primary"><?php echo $todosacessos;?></h3>
              <h3>de</h3>
              <h3><?php echo $todosacessos;?></h3>
            </div>
          </div>
          <div class="item offline">
            <div class="icon">
              <span class="material-icons-sharp"><ion-icon name="analytics-outline"></ion-icon></span>
            </div>
            <div class="right">
              <div class="info">
                <h3>Limite Disponível</h3>
              </div>
              <h3 class="danger"><?php echo $disponiveis;?></h3>
              <h3>de</h3>
              <h3><?php echo $todosacessos;?>
            </div>
          </div>
          <div class="item customers">
            <div class="icon">
              <span class="material-icons-sharp"><ion-icon name="layers-outline"></ion-icon></span>
            </div>
            <div class="right">
              <div class="info">
                <h3>Limite Usado</h3>
              </div>
              <h3 class="success"><?php echo $qtddoserverusado;?></h3>
              <h3>de</h3>
              <h3><?php echo $disponiveis;?></h3>
            </div>
          </div>
            </div>
    <script src="/CSS/index.js"></script>