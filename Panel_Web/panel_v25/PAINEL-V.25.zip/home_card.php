                         <?php

                         $SQLAcessoServidor = "SELECT * FROM acesso_servidor where id_usuario = '".$_SESSION['usuarioID']."' ";
                         $SQLAcessoServidor = $conn->prepare($SQLAcessoServidor);
                         $SQLAcessoServidor->execute();



                         // output data of each row
                         if (($SQLAcessoServidor->rowCount()) > 0) {

                             while($row = $SQLAcessoServidor->fetch())


                             {

                                 $contas=0;
                                 $total_acesso_ssh = 0;

                                 $SQLAcessoSSH = "SELECT sum(acesso) AS quantidade  FROM usuario_ssh where id_usuario='".$_SESSION['usuarioID']."' and id_servidor='".$row['id_servidor']."'";
                                 $SQLAcessoSSH = $conn->prepare($SQLAcessoSSH);
                                 $SQLAcessoSSH->execute();
                                 $SQLAcessoSSH = $SQLAcessoSSH->fetch();
                                 $total_acesso_ssh += $SQLAcessoSSH['quantidade'];

                                 $SQLContasSSH = "select * from usuario_ssh WHERE id_usuario = '".$_SESSION['usuarioID']."' and id_servidor='".$row['id_servidor']."'";
                                 $SQLContasSSH = $conn->prepare($SQLContasSSH);
                                 $SQLContasSSH->execute();
                                 $contas += $SQLContasSSH->rowCount();

                                 $SQLUserSub = "select * from usuario WHERE id_mestre = '".$_SESSION['usuarioID']."' and subrevenda='nao'";
                                 $SQLUserSub = $conn->prepare($SQLUserSub);
                                 $SQLUserSub->execute();

                                 if (($SQLUserSub->rowCount()) > 0) {

                                     while($rowS = $SQLUserSub->fetch()) {
                                         $SQLContasSSH = "select * from usuario_ssh WHERE id_usuario = '".$rowS['id_usuario']."'  and id_servidor='".$row['id_servidor']."'";
                                         $SQLContasSSH = $conn->prepare($SQLContasSSH);
                                         $SQLContasSSH->execute();
                                         $contas += $SQLContasSSH->rowCount();

                                         $SQLAcessoSSH = "SELECT sum(acesso) AS quantidade  FROM usuario_ssh where id_usuario='".$rowS['id_usuario']."'  and id_servidor='".$row['id_servidor']."'";
                                         $SQLAcessoSSH = $conn->prepare($SQLAcessoSSH);
                                         $SQLAcessoSSH->execute();
                                         $SQLAcessoSSH = $SQLAcessoSSH->fetch();
                                         $total_acesso_ssh += $SQLAcessoSSH['quantidade'];


                                     }
                                 }




                                 $todosacessos2=0;

                                 $SQLqtdserveracessos2= "SELECT sum(qtd) as todosacessos FROM  acesso_servidor where id_usuario = '".$row['id_usuario']."' and id_servidor='".$row['id_servidor']."' ";
                                 $SQLqtdserveracessos2 = $conn->prepare($SQLqtdserveracessos2);
                                 $SQLqtdserveracessos2->execute();

                                 $totalacess2=$SQLqtdserveracessos2->fetch();

                                 $todosacessos2+=$totalacess2['todosacessos'];

                                //Calculo Porcentagem

                                 $porcentagem = ($total_acesso_ssh/$todosacessos2)*100; // %

                                 $resultado2 = $porcentagem;

                                 $valor_porcetage = round($resultado2);

                                 if($valor_porcetage>=100){
                                     $valor_porcetage=100;
                                 }
                                 if($valor_porcetage<=0){
                                     $valor_porcetage=0;
                                 }
                                 if(($valor_porcetage>=70)and($valor_porcetage<90)){
                                     $sucessobar="warning";
                                     $bgbar2="warning";
                                 }elseif($valor_porcetage>=90){
                                     $sucessobar="danger";
                                     $bgbar2="danger";
                                 }else{
                                     $sucessobar="success";
                                     $bgbar2="success";
                                 }


                                 $SQLServidor= "select * from servidor WHERE id_servidor = '".$row['id_servidor']."' ";
                                 $SQLServidor = $conn->prepare($SQLServidor);
                                 $SQLServidor->execute();
                                 $servidor =  $SQLServidor->fetch();


                                 $SQLopen = "select * from ovpn WHERE servidor_id = '".$row['id_servidor']."' ";
                                 $SQLopen = $conn->prepare($SQLopen);
                                 $SQLopen->execute();
                                 if($SQLopen->rowCount()>0){
                                     $openvpn=$SQLopen->fetch();
                                     $texto="<a href='../admin/pages/servidor/baixar_ovpn.php?id=".$openvpn['id']."' class=\"label label-info\">Baixar</a>";
                                 }else{
                                     $texto="<span class=\"label label-danger\">Indisponivel</span>";
                                 }

                                 //Calcula os dias restante
                                 $data_atual = date("Y-m-d");
                                 $data_validade = $row['validade'];
                                 if($data_validade > $data_atual){
                                     $data1 = new DateTime( $data_validade );
                                     $data2 = new DateTime( $data_atual );
                                     $dias_acesso = 0;
                                     $diferenca = $data1->diff( $data2 );
                                     $ano = $diferenca->y * 364 ;
                                     $mes = $diferenca->m * 30;
                                     $dia = $diferenca->d;
                                     $dias_acesso = $ano + $mes + $dia;

                                 }else{
                                     $dias_acesso = 0;
                                 }



                                 ?>

                             <?php }
                         }

                         ?>
                         
        <h1>Dashboard - <?php echo strtoupper($usuario['nome']);?></h1>
        <div class="date">
            <h3>Vencimento: </h3>
            <p><?php echo $dias_acesso."  dias   "; ?></p>
        </div>
        <div class="insights">
          <div class="sales">
            <span class="material-icons-sharp"><ion-icon name="person-circle-outline"></ion-icon></span>
            <div class="middle">
              <div class="left">
                <h2>Usuários Criado</h2>
               <a href="/user_lista.php"><font color="#747fe1">Ver Todos</font></a>
              </div>
              <div class="progress">
                <svg>
                  <circle cx="38" cy="38" r="36"></circle>
                </svg>
                <div class="number">
                <h1><?php echo $quantidade_ssh; ?></h1>
                </div>
              </div>
            </div>
          </div>
          <!------------ END OF SALES -------------->
          <div class="expenses">
            <span class="material-icons-sharp"><ion-icon name="people-circle-outline"></ion-icon></span>
            <div class="middle">
              <div class="left">
                <h2>Usuários Online</h2>
               <a href=""><font color="#747fe1">10seg Update</font></a>
              </div>
              <div class="progress">
                <svg>
                  <circle cx="38" cy="38" r="36"></circle>
                </svg>
                <div class="number">
                <h1 id="online_nav"><?php echo $total_acesso_ssh_online; ?></h1>
                </div>
              </div>
            </div>
          </div>
          <!------------ END OF SALES -------------->
          <div class="income">
            <span class="material-icons-sharp"><ion-icon name="server"></ion-icon></span>
            <div class="middle">
              <div class="left">
                <h2>Servidor Disponível</h2>
               <a href="/server.php"><font color="#747fe1">Ver Todos</font></a>
              </div>
              <div class="progress">
                <svg>
                  <circle cx="38" cy="38" r="36"></circle>
                </svg>
                <div class="number">
                <h1><?php echo $acesso_servidor; ?></h1>
            </div>
           </div>
          </div>
          <!------------ END OF INCOME -------------->
        </div>
        <!------------ END OF INSIGHTS -------------->
      </div>
            
        <?php


        if(isset($_GET["page"])){
            $page = $_GET["page"];
            if($page and file_exists("".$page.".php")) {
                include("".$page.".php");
            } else {
                include("home_online.php");
            }
        }else{
            include("home_online.php");
        }

        ?>