<?php
include("SubMenu.php")
?>
    <main>
     <center>
      <h1>Lista Usuarios Criado</h1>
        <div class="recent-orders">
         <div class="scroller">
          <table class="js-sort-table" id="customers">
                        <tr>
                            
                            <th>
                            SERVER
                            </th>
                               
                            <th>
                            STATUS
                            </th>
                                             
                            <th>
                            LOGIN
                            </th>
                            
                            <th>
                            SENHA
                            </th>
                            
                            <th>
                            LIMITE
                            </th>
                            
                            <th>
                            VALIDO
                            </th>
                            
                            <th>
                            EDITAR
                            </th>
                            
                            <th>
                            EXCLUIR
                            </th>
                            
                        </tr>
                        <?php

                        $SQLSub = "SELECT * FROM usuario where id_usuario= '".$_SESSION['usuarioID']."'";
                        $SQLSub = $conn->prepare($SQLSub);
                        $SQLSub->execute();



                        if(($SQLSub->rowCount()) > 0){
                            while($rowSub = $SQLSub->fetch()) {
                                $SQLSubSSH = "SELECT * FROM usuario_ssh, servidor  where usuario_ssh.id_servidor = servidor.id_servidor and usuario_ssh.id_usuario = '".$_SESSION['usuarioID']."' ORDER BY status";
                                $SQLSubSSH = $conn->prepare($SQLSubSSH);
                                $SQLSubSSH->execute();


                                if(($SQLSubSSH->rowCount()) > 0){
                                    while($row = $SQLSubSSH->fetch()){
                                        $status="";
                                        if($row['status']== 1){
                                            $status="Ativo";
                                            $sts ="on";
                                        }else{
                                            $status="Inativo";
                                            $sts ="off";
                                        }

                                        $color = "";
                                        if($row['status']== 2){

                                            $color = "bgcolor=''#FF6347";
                                        }
                                        //Calcula os dias restante
                                        $data_atual = date("Y-m-d ");
                                        $data_validade = $row['data_validade'];
                                        if($data_validade > $data_atual){
                                            $data1 = new DateTime( $data_validade );
                                            $data2 = new DateTime( $data_atual );
                                            $dias_acesso = 0;
                                            $diferenca = $data1->diff( $data2 );
                                            $ano = $diferenca->y * 364 ;
                                            $mes = $diferenca->m * 30;
                                            $dia = $diferenca->d;
                                            $dias_acesso = $ano + $mes + $dia;

                                        }else{
                                            $dias_acesso = 0;
                                        }


                                        $pegando = "SELECT * FROM usuario_ssh  where id_usuario_ssh='".$row['id_usuario_ssh']."'";
                                        $pegando = $conn->prepare($pegando);
                                        $pegando ->execute();
                                        $pegasenha = $pegando->fetch();

                                        $SQLopen = "select * from ovpn WHERE servidor_id = '".$row['id_servidor']."' ";
                                        $SQLopen = $conn->prepare($SQLopen);
                                        $SQLopen->execute();
                                        if($SQLopen->rowCount()>0){
                                            $openvpn=$SQLopen->fetch();
                                        }


                                        ?>
                                        <tr <?php echo $color; ?>>

                      <td>
                      <?php echo $row['nome'];?>
                      </td>
                         
                      <td>
                      <div class="<?php echo $sts;?>">
                      <?php echo $status; ?>
                      </div>
                      </td>
                                              
                      <td>
                      <?php echo $row['login'];?>
                      </td>
                      
                      <td>
                      <?php echo $pegasenha['senha'];?>
                      </td>
                      
                      <td>
                      <?php echo $row['acesso'];?>
                      </td>
                      
                      <td>
                      <?php echo $dias_acesso." dias "; ?>
                      </td>
                      
                      <td>
                     <a href="/SubMenu.php?page=ssh/editar&id_ssh=<?php echo $row['id_usuario_ssh'];?>">
                     <button class="botao2">
                     <ion-icon name="brush"></ion-icon>
                     </button>
                     </a>
                      </td>
                      
                      <td>
                     <form role="form2" action="pages/system/funcoes.conta.ssh.php" onsubmit="return confirm('Tem certeza que deseja excluir o usuário?');" method="post" class="form-horizontal">
                     <input type="hidden"  id="diretorio" name="diretorio" value="/user_lista.php"  >
                     <input type="hidden"  id="id_usuario_ssh" name="id_usuario_ssh" value="<?php echo $row['id_usuario_ssh']; ?>"  >
                     <input type="hidden"  id="owner" name="owner" value="<?php echo $_SESSION['usuarioID']; ?>"  >
                     
                     <button type="submit" data-toggle="tooltip" id="op" name="op" value="deletar" class="botao1"> 
                     <ion-icon name="trash-bin"></ion-icon>
                     </button>
                     </form>
                     </td>
                     
                      </tr>
                                        <?php
                                    }

                                }

                            }
                        }
                        ?>
                     </table>
                   </div>
                 </div>
                 </main>
      <!----------------- END OF MAIN -------------------->
      <div class="right">
        <div class="top">
          <button id="menu-btn">
            <span class="material-icons-sharp"><ion-icon name="menu-sharp"></ion-icon></span>
          </button>
          <div class="theme-toggler">
            <span class="material-icons-sharp active">light_mode</span>
            <span class="material-icons-sharp">dark_mode</span>
          </div>
          <div class="profile">
            <div class="info">
              <p>Olá, <b><?php echo strtoupper($usuario['nome']);?></b></p>
              <small class="text-muted"><?php echo $tipouser;?></small>
            </div>
            <div class="profile-photo">
             <a href="/SubMenu.php?page=admin/dados">
              <img src="/PNG/<?php echo $avatarusu;?>" /></a>
            </div>
          </div>
        </div>
        <script type="text/javascript" src="/SYSTEM/sort-table.js"></script>
        <script src="/CSS/index.js"></script>