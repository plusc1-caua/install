<?php
$procnoticias= "select * FROM noticias where status='ativo'";
$procnoticias = $conn->prepare($procnoticias);
$procnoticias->execute();

if($usuario['tipo']=='revenda'){
        // Clientes
  $SQLbuscaclientes= "select * from usuario where tipo='vpn' and id_mestre='".$usuario['id_usuario']."'";
  $SQLbuscaclientes = $conn->prepare($SQLbuscaclientes);
  $SQLbuscaclientes->execute();
  $totalclientes = $SQLbuscaclientes->rowCount();

         // Servidores
  $SQLbuscaservidores= "select * from acesso_servidor where id_usuario='".$usuario['id_usuario']."'";
  $SQLbuscaservidores = $conn->prepare($SQLbuscaservidores);
  $SQLbuscaservidores->execute();
  $servidoresclientes = $SQLbuscaservidores->rowCount();

        // Cotas
  $totaldecotas=0;
  $SQLbuscacontasssh= "select sum(qtd) as cotas from acesso_servidor where id_usuario='".$usuario['id_usuario']."'";
  $SQLbuscacontasssh = $conn->prepare($SQLbuscacontasssh);
  $SQLbuscacontasssh->execute();
  $minhascotas = $SQLbuscacontasssh->fetch();
  $totaldecotas+=$minhascotas['cotas'];


}else{
        // Contas
  $SQLbuscacontinhas= "select * from usuario_ssh where id_usuario='".$usuario['id_usuario']."'";
  $SQLbuscacontinhas = $conn->prepare($SQLbuscacontinhas);
  $SQLbuscacontinhas->execute();
  $totalcontas = $SQLbuscacontinhas->rowCount();

        // Cotas
  $totaldecotas2=0;
  $SQLbuscacontasssh2= "select sum(acesso) as cotas from usuario_ssh where id_usuario='".$usuario['id_usuario']."'";
  $SQLbuscacontasssh2 = $conn->prepare($SQLbuscacontasssh2);
  $SQLbuscacontasssh2->execute();
  $minhascotas2 = $SQLbuscacontasssh2->fetch();
  $totaldecotas2+=$minhascotas2['cotas'];

}

?>

<!-- Noticias -->
<?php if($procnoticias->rowCount()>0){
 $noticia=$procnoticias->fetch();

 $datapega=$noticia['data'];
 $data = date('D',strtotime($datapega));
 $mes = date('M',strtotime($datapega));
 $dia = date('d',strtotime($datapega));
 $ano = date('Y',strtotime($datapega));

 $semana = array(
  'Sun' => 'Domingo',
  'Mon' => 'Segunda-Feira',
  'Tue' => 'Terça-Feira',
  'Wed' => 'Quarta-Feira',
  'Thu' => 'Quinta-Feira',
  'Fri' => 'Sexta-Feira',
  'Sat' => 'Sábado'
);

 $mes_extenso = array(
  'Jan' => 'Janeiro',
  'Feb' => 'Fevereiro',
  'Mar' => 'Marco',
  'Apr' => 'Abril',
  'May' => 'Maio',
  'Jun' => 'Junho',
  'Jul' => 'Julho',
  'Aug' => 'Agosto',
  'Nov' => 'Novembro',
  'Sep' => 'Setembro',
  'Oct' => 'Outubro',
  'Dec' => 'Dezembro'
);


?>

      <div class="insights">
         <div class="sales">
          <center>
            <h2><?php echo $noticia['titulo'];?> </h2>
            <?php echo $noticia['subtitulo'];?> <br/>
            <?php echo $noticia['msg'];?><br/>
            <?php echo $semana["$data"] . ", {$dia} de " . $mes_extenso["$mes"] . " de {$ano}";;?>
        </center>
         </div>
          </div>
           <br>
<?php } ?>

        <?php


        if(isset($_GET["page"])){
            $page = $_GET["page"];
            if($page and file_exists("".$page.".php")) {
                include("".$page.".php");
            } else {
                include("home_card.php");
            }
        }else{
            include("home_card.php");
        }

        ?>