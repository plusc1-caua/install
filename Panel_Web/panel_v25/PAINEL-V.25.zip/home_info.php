
      <div class="right">
        <div class="top">
          <button id="menu-btn">
            <span class="material-icons-sharp"><ion-icon name="menu-sharp"></ion-icon></span>
          </button>
          <div class="theme-toggler">
            <span class="material-icons-sharp active">light_mode</span>
            <span class="material-icons-sharp">dark_mode</span>
          </div>
          <div class="profile">
            <div class="info">
              <p>Olá, <b><?php echo strtoupper($usuario['nome']);?></b></p>
              <small class="text-muted"><?php echo $tipouser;?></small>
            </div>
            <div class="profile-photo">
             <a href="/SubMenu.php?page=admin/dados">
              <img src="/PNG/<?php echo $avatarusu;?>" /></a>
            </div>
          </div>
        </div>
        <div class="sales-analytics">
          <h2>Progresso de Uso</h2>
          
          <div class="item online">
            <div class="icon">
              <span class="material-icons-sharp"><ion-icon name="stats-chart-outline"></ion-icon></span>
            </div>
            <div class="right">
              <div class="info">
                <h3>Limite Total</h3>
              </div>
              <h3 class="primary"><?php echo $todosacessos;?></h3>
              <h3>de</h3>
              <h3><?php echo $todosacessos;?></h3>
            </div>
          </div>
          
          <div class="item offline">
            <div class="icon">
              <span class="material-icons-sharp"><ion-icon name="analytics-outline"></ion-icon></span>
            </div>            
            <div class="right">
              <div class="info">
                <h3>Limite Disponível</h3>
              </div>
              <h3 class="danger"><?php echo $disponiveis;?></h3>
              <h3>de</h3>
              <h3><?php echo $todosacessos;?></h3>
            </div>
          </div>
          
          <div class="item customers">
            <div class="icon">
              <span class="material-icons-sharp"><ion-icon name="layers-outline"></ion-icon></span>
            </div>            
            <div class="right">
              <div class="info">
                <h3>Limite Usado</h3>
              </div>
              <h3 class="success"><?php echo $qtddoserverusado;?></h3>
              <h3>de</h3>
              <h3><?php echo $disponiveis;?></h3>
            </div>
          </div>
                                                 
        <div class="sales-analytics">
          <h2>Notificação</h2>
          
          <div class="item online">
            <div class="icon">
              <span class="material-icons-sharp"><ion-icon name="chatbubbles-outline"></ion-icon></span>
            </div>
            <div class="right">
              <div class="info">
                <h3>Mensagem</h3>
              </div>
              <h3 class="success"><?php echo $totalnoti_outros;?></h3>
              <h3>de</h3>
              <h3><?php echo $totalnoti_outros;?></h3>
            </div>
          </div>
          
          <div class="item offline">
            <div class="icon">
              <span class="material-icons-sharp"><ion-icon name="clipboard-outline"></ion-icon></span>
            </div>
            <div class="right">
              <div class="info">
                <h3>Histórico</h3>
              </div>
              <h3 class="danger"><?php echo $totalnoti_contas;?></h3>
              <h3>de</h3>
              <h3><?php echo $totalnoti_contas;?></h3>
            </div>
           </div>
              
          <div class="item add-product">
            <div>
              <span class="material-icons-sharp"><ion-icon name="add-outline"></ion-icon></span>
              <h3>Not available</h3>
            </div>
          </div>
        </div>
        
    <script src="/CSS/index.js"></script>