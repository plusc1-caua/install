       <div class="recent-orders">
          <h2>Usuários Online</h2>
           <table>
            <thead>
              <tr>
                <th>NOME</th>
                <th>CONEXÃO</th>
                <th>STATUS</th>
              </tr>
            </thead>
            <tbody>
                        <?php

                        $SQLSub = "SELECT * FROM usuario where id_usuario= '".$_SESSION['usuarioID']."'";
                        $SQLSub = $conn->prepare($SQLSub);
                        $SQLSub->execute();



                        if(($SQLSub->rowCount()) > 0){
                            while($rowSub = $SQLSub->fetch()) {
                                $SQLSubSSH = "SELECT * FROM usuario_ssh, servidor  where usuario_ssh.id_servidor = servidor.id_servidor and usuario_ssh.id_usuario = '".$_SESSION['usuarioID']."'";
                                $SQLSubSSH = $conn->prepare($SQLSubSSH);
                                $SQLSubSSH->execute();


                                if(($SQLSubSSH->rowCount()) > 0){
                                    while($row = $SQLSubSSH->fetch()){
                                        $status="";
                                        if($row['status']== 1){
                                            $status="Ativo";
                                        }else{
                                            $status="Vencido";
                                        }
                                        if($row['online'] != 0){
                                            //Calcula os dias restante
                                            $data_atual = date("Y-m-d ");
                                            $data_validade = $row['data_validade'];
                                            if($data_validade > $data_atual){
                                                $data1 = new DateTime( $data_validade );
                                                $data2 = new DateTime( $data_atual );
                                                $dias_acesso = 0;
                                                $diferenca = $data1->diff( $data2 );
                                                $ano = $diferenca->y * 364 ;
                                                $mes = $diferenca->m * 30;
                                                $dia = $diferenca->d;
                                                $dias_acesso = $ano + $mes + $dia;

                                            }else{
                                                $dias_acesso = 0;
                                            }

                                            ?>
             <tr>
                            <td><?php echo $row['login'];?></td>
                            
                            <td class="primary">0<?php echo $row['online'];?> de 0<?php echo $row['acesso'];?></td>
                            
                            <td class="warning">Online</td>
                            
                        </tr>
                                            <?php
                                        }

                                    }

                                }

                            }
                        }



                        if($usuario['tipo']=="revenda"){



                            $SQLSub = "SELECT * FROM usuario where id_mestre= '".$_SESSION['usuarioID']."' and subrevenda='nao'";
                            $SQLSub = $conn->prepare($SQLSub);
                            $SQLSub->execute();


                            if(($SQLSub->rowCount()) > 0){
                                while($rowSub = $SQLSub->fetch()) {
                                    $SQLSSH = "SELECT * FROM usuario_ssh, servidor  where usuario_ssh.id_servidor = servidor.id_servidor and usuario_ssh.id_usuario = '".$rowSub['id_usuario']."'";
                                    $SQLSSH = $conn->prepare($SQLSSH);
                                    $SQLSSH->execute();


                                    if(($SQLSSH->rowCount()) > 0){
                                        while($row = $SQLSSH->fetch()){
                                            $status="";
                                            if($row['status']== 1){
                                                $status="Ativo";
                                            }else{
                                                $status="Desativado";
                                            }
                                            if($row['online'] != 0){


                                                ?>
                                                <?php
                                            }

                                        }

                                    }

                                }
                            }




                        }



                        ?>
            </tbody>
          </table>
        </div>
      </main>      
            
        <?php


        if(isset($_GET["page"])){
            $page = $_GET["page"];
            if($page and file_exists("".$page.".php")) {
                include("".$page.".php");
            } else {
                include("home_info.php");
            }
        }else{
            include("home_info.php");
        }

        ?>