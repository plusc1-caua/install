<?php 
require_once("pages/system/seguranca.php");

 if(isset($_GET["p"])){
	 
	 if($_GET["p"]=="admin"){
		$id_owner  = 0;				 
	 }else{
		$SQLUsuario = "select * from usuario where token_user = '".$_GET['p']."' ";
        $SQLUsuario = $conn->prepare($SQLUsuario);
        $SQLUsuario->execute();
		
	    if(($SQLUsuario->rowCount()) > 0){
		   $usuario = $SQLUsuario->fetch();
		   $id_owner  = $usuario['id_usuario'];
  
		}else{
		   echo '<script type="text/javascript">';
		   echo 	'alert("Nao encontrado!");';
		   echo	'window.location="login.php";';
		   echo '</script>'; 
		   exit;
			
		}	 

        $SQLSrv = "select * from servidor where demo='1' LIMIT 1";
        $SQLSrv = $conn->prepare($SQLSrv);
        $SQLSrv->execute();
				
	    if(($SQLSrv->rowCount()) < 0){
			echo '<script type="text/javascript">';
		   echo 	'alert("Nao disponivel!");';
		   echo	'window.location="login.php";';
		   echo '</script>'; 
		   exit;
			
		}else{
			$servidor = $SQLSrv->fetch();
		}
		   
	   
		 
		 
	 }
	
   }else{
	   
	    echo '<script type="text/javascript">';
		echo	'window.location="login.php";';
		echo '</script>'; 
		exit;
   }

   function geraSenha(){
				

					$salt = "1234";
					srand((double)microtime()*1000000); 

					$i = 0;
                    $pass = 0;
					while($i <= 7){

						$num = rand() % 10;
						$tmp = substr($salt, $num, 1);
						$pass = $pass . $tmp;
						$i++;

					}
					
					
					

					return $pass;

				}
	
    function geraLoginSSH(){
				

					$salt = "vip10";
					srand((double)microtime()*1000000); 

					$i = 0;
                    $pass = 0;
					while($i <= 7){

						$num = rand() % 10;
						$tmp = substr($salt, $num, 1);
						$pass = $pass . $tmp;
						$i++;

					}
					
					
					

					return $pass;

				}
	
$login_ssh = geraLoginSSH();

?>
<?php
    
	
   
	$SQLAcessoSRV = "SELECT * FROM servidor WHERE  demo='1' LIMIT 1";
    $SQLAcessoSRV = $conn->prepare($SQLAcessoSRV);
    $SQLAcessoSRV->execute();
   

if (($SQLAcessoSRV->rowCount()) > 0) {
    // output data of each row
   $row_srv_principal = $SQLAcessoSRV->fetch();
		
		?>
        
	<!--<option value="<?php echo $row_srv_principal['id_servidor'];?>" > <?php echo $row_srv_principal['nome'];?> - <?php echo $row_srv_principal['ip_servidor'];?> </option>-->
	
   <?php 
}

	
	$SQLAcessoSRV = "SELECT * FROM servidor WHERE   demo='1' ";
    $SQLAcessoSRV = $conn->prepare($SQLAcessoSRV);
    $SQLAcessoSRV->execute();
	

if (($SQLAcessoSRV->rowCount()) > 0) {
    // output data of each row
    while($row_srv = $SQLAcessoSRV->fetch()) {
		
		?>
		<div style="display: none;">
 <center> <b class="text-info m-l-5"> <i class="far fa-server"></i>  <b> SERVIDOR DISPONIVEL</b></center>       
	<center><option class="rounded-lg btn btn-outline-info  waves-effect waves-light" value=" <?php echo $row_srv['id_servidor'];?>" >  <?php echo $row_srv['nome'];?> </option></p></center>
	</div>
   <?php }
}

?>
<!DOCTYPE html>
<html>
<head>
	<title>Animated Login Form</title>
	<link rel="stylesheet" type="text/css" href="CSS/login.css">
	<link href="https://fonts.googleapis.com/css?family=Poppins:600&display=swap" rel="stylesheet">
	<script src="https://kit.fontawesome.com/a81368914c.js"></script>
	<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
	<img class="wave" src="PNG/inicial/fundo.png">
	<div class="container">
		<div class="img">
			<img src="PNG/inicial/icon.svg">
		</div>
		<div class="login-content">
			<form action="new_afiliado.php" onsubmit="return confirm('Deseja confirmar seu cadastro?');" method="post">
				<img src="PNG/inicial/avatar.svg">
				<h2 class="title">CADASTRE-SE!</h2>
			
			   <div style="display: none;">
	           <input type="hidden" class="form-control"  id="p" name="p" value="<?php echo $_GET['p'];?>">
	           <input type="hidden" class="form-control"  id="owner" name="owner" value="<?php echo $id_owner;?>">
               <?php if($_GET['p']!="admin"){?>
               <input required="required" type="text" disabled class="form-control" value="<?php echo $usuario['login'];?>"  >
	           <?php } ?>
	           </div>
	           
           		<div class="input-div one">
           		   <div class="i">
           		   		<i class="fas fa-user"></i>
           		   </div>
           		   <div class="div">
           		   		<h5>Nome do painel</h5>
           		   		<input required="required" type="text" class="input" id="nome" name="nome" >
           		   </div>
           		</div>
           		
           		<div class="input-div pass">
           		   <div class="i"> 
           		    	<i class="fas fa-user"></i>
           		   </div>
           		   <div class="div">
           		    	<h5>Usuário de acesso</h5>
           		    	<input required="required" type="text" class="input" id="login_sistema" name="login_sistema">
            	   </div>
            	</div>
            	
           		<div class="input-div pass">
           		   <div class="i"> 
           		    	<i class="fas fa-lock"></i>
           		   </div>
           		   <div class="div">
           		    	<h5>Senha de acesso</h5>
           		    	<input type="password" class="input" id="senha_sistema" name="senha_sistema">
            	   </div>
            	</div>
            	
           		<div class="input-div pass">
           		   <div class="i"> 
           		    	<i class="fas fa-phone"></i>
           		   </div>
           		   <div class="div">
           		    	<h5>Telefone contato</h5>
           		    <input type="text" class="input" id="celular" name="celular"  min="11">
            	   </div>
            	</div>
            	<div style="display: none;">
       
	  <?php if($_GET['p']=="admin"){?>
      <input type="radio" name="tipo" id="tipo" class="minimal" checked value="revenda">
                
		<?php }else{ ?>
	  <input type="hidden" name="tipo" id="tipo" value="revenda">
	    <?php } ?>
	    
      <input required="required" type="text" class="form-control" placeholder="Login" id="login_ssh" name="login_ssh" value="<?php echo $login_ssh;?>">
      
      <input type="password" class="form-control"  disabled placeholder="A Senha será enviada no Painel" >
              </div>
      
            	<a href="login.php">Já possui uma conta? Faça Login</a>
	  <center><button type="submit" class="btn"><b>CRIAR CONTA</b></button></center>
            </form>
        </div>
    </div>
    <script type="text/javascript" src="CSS/login.js"></script>
</body>
</html>
